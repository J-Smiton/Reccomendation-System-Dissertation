function MF_Fringe_Players = Suggest_MF_Fringe_Players(MF_Vector, Target_MF_ClubTier, Signing_ClubTier);

    Target_MF_ClubTier = MF_Vector.ClubTier;
    %Specify variable for club of players being suggested
    Fringe_FW_Minutes = MF_Vector.Min;
    %Specify variable for minutes of fringe players

    MF_Fringe_Players = table();
    %Create a table of fringe players

    Non_Fringe_Players = {'Marco Asensio', 'Harvey Elliot', 'João Félix', 'Douglas Luiz', 'Rodri', 'Lewis Miley', 'Mason Mount', 'James Ward-Prowse'};
    %Create a list of notable exceptions (for injuries and January
    %transfers)

    if Signing_ClubTier >= 4
    %Only for tier 4 and 5 clubs
        MF_Fringe_Targets = Target_MF_ClubTier <= 2;
        %Suggest tier 1+2 players
        Fringe_MFs = Fringe_FW_Minutes <= 500;
        %Who have 500 or less minutes
        Eligible_Fringe_MFs = Fringe_MFs & MF_Fringe_Targets;
        %Eligible for a fringe signing if they're tier1/2 and have <500 min
        MF_Fringe_Players = MF_Vector(Eligible_Fringe_MFs, :);
        %Create variable holding fringe players
        Excluded_MFs = ismember(MF_Fringe_Players.Player, Non_Fringe_Players);
        %Implement exclusions 
        MF_Fringe_Players(Excluded_MFs, :) = [];
        %Minus excluded midfielders

        Opportunity_Label = repmat("Fringe Transfer", height(MF_Fringe_Players), 1);
        %Add 'fringe players' to opportunity label for players over 23
        Opportunity_Label(MF_Fringe_Players.Age <= 23) = "Loan Opportunity";
        %Add 'loan opportunity' to players 23 and under
        MF_Fringe_Players.Opportunity = Opportunity_Label;
        %Apply label with description of potential signing

        MF_Fringe_Players = sortrows(MF_Fringe_Players, 'Rk');
        %Sort players by their 'Rk' (Rank)-Alphabetical
    else
        MF_Fringe_Players = table();
        %Empty table for tier 1, 2 and 3 clubs
    end 
end

