function [Top_DF_Suggestions] = SigningLikelihood_DFs(Top_DF_Suggestions, ClubName);
    
    Untouchable_DF = {'William Saliba', 'Alessandro Bastoni', 'Gabriel Magalhães', 'William Pacho', 'Nuno Mendes', 'Virgil Van Dijk', 'Pau Cubarsí'};
    %Lists Unlikely signings based on players being superstars
    
    Untouchable_DFs = ismember(Top_DF_Suggestions.Player, Untouchable_DF);
    %Puts them in a list

    Untouchable_Flag = Untouchable_DFs;
    %Flags unlikely signings for superstars

    Loyal_DF = {'Christian Günter', 'Óscar de Marcos', 'Presnel Kimpembe', 'José Gayà', 'Yeray Álvarez', 'José María Giménez', 'Artiz Elustondo', 'Dani Carvajal', 'Igor Zubeldia', 'Luke Shaw', 'Max Rosenfelder', 'Lukas Klostermann', 'Ben Davies', 'Jamaal Lascelles', 'Noahkai Banks', 'Nico Elvedi', 'Joe Gomez', 'Patric', 'Willi Orbán', 'Lucas Vázquez', 'Milos Veljkovic', 'Brendan Chardonnet', 'Aitor Paredes', 'Tyrick Mitchell', 'John Stones', 'Rico Henry', 'Adam Marusic', 'Aihen Muñoz', 'Victor Lindelöf', 'Michael Keane', 'Andrew Robertson', 'Virgil Van Dijk', 'Berat Djimsiti'};
    %Lists Forwards who have been/are loyal to their club

    Loyal_DFs = ismember(Top_DF_Suggestions.Player, Loyal_DF);
    %Puts them in a lsit

    Loyal_Flag = Loyal_DFs;
    %Flags unlikely signings for loyal players

    RivalryPairs = {
        'Arsenal', 'Tottenham';
        'Real Madrid', 'Barcelona';
        'Manchester Utd', 'Liverpool';
        'Roma', 'Lazio';
        'Inter', 'Milan';
        'Paris S-G', 'Marseille';
        'Real Sociedad', 'Athletic Club';
        'Sevilla', 'Betis';
        'Fiorentina', 'Juventus';
        'Lyon', 'Saint-Étienne';
        };
    %Lists rivalries where players are unlikely to transfer between

    Rival_Flag = false(height(Top_DF_Suggestions), 1);
    %Set rival flag to default to false

    for i = 1:size(RivalryPairs, 1)
        ClubA = RivalryPairs{i, 1};
        ClubB = RivalryPairs{i, 2};
        %Interprets rival pairs as A and B

        Is_Rival = (strcmp(Top_DF_Suggestions.Squad_ClubTiers, ClubA) & strcmp(ClubName, ClubB)) | (strcmp(Top_DF_Suggestions.Squad_ClubTiers, ClubB) & strcmp(ClubName, ClubA));
        %Checks for transfer both ways between rival clubs

        Rival_Flag = Rival_Flag | Is_Rival;
        %Flag player if involved in transfer between rivals
    end

    Unlikely_Flag = Untouchable_Flag | Rival_Flag | Loyal_Flag;

    Top_DF_Suggestions.Unlikely_Label = repmat({''}, height(Top_DF_Suggestions), 1);
    %Adds a column in the table and lists if a signing is unlikely or not

    Top_DF_Suggestions.Unlikely_Label(Untouchable_Flag) = strcat(Top_DF_Suggestions.Unlikely_Label(Untouchable_Flag), '*Superstar');
    Top_DF_Suggestions.Unlikely_Label(Rival_Flag) = strcat(Top_DF_Suggestions.Unlikely_Label(Rival_Flag), '*Rival');
    Top_DF_Suggestions.Unlikely_Label(Loyal_Flag) = strcat(Top_DF_Suggestions.Unlikely_Label(Loyal_Flag), '*Loyal');
    %Writes in reasons for a potential unlikely signing
end

