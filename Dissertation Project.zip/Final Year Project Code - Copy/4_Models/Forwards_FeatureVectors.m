FW_Vector = readtable('Norm_DissData_FW_Val_Final.csv');
%Load normalised forward data
FW_Features = ["Gls_norm", "G_A_norm", "xG_norm", "npxG_xAG_norm", "PrgC_norm", "SoT__norm"];
%Add chosen stats to feature list
FW_FeatureMatrix = FW_Vector{:, FW_Features};
%Implement this into the feature matrix

Club_Vector = readtable('Norm_finalTeamStats.csv');
%Load normalised club data
Club_Features = ["Ttl_Gls_norm", "Ttl_G_A_norm", "Ttl_xG_norm", "Ttl_npxG_xAG_norm", "Ttl_PrgC_norm", "Avg_SoT__norm"];
%Add the same stats to feature list
Club_Matrix = Club_Vector{:, Club_Features};
%Implement this into the feature matrix
Club_Profile = Club_Matrix(1, :);
%Set this up as the club profile

%ClubName = input('Enter club name:', 's')
%Manual entering for when UI not in use
ClubName = GetClubName()
%Take ClubName from UI dropdown
Club = strcmp(Club_Vector.Squad, ClubName);
%Compare inputted club with those in the club vector

if any (Club)
    ClubTier = Club_Vector.ClubTier(Club);
    %If there is a club match then apply signability rule
    Signability = FW_Vector.ValTiers >= (ClubTier - 1) & FW_Vector.ValTiers <= ClubTier;
    %Club can sign 1 val tier higher or any below/same
else
    error('Club not found, check list for how to input Club Names!');
    %Error if there is no matching club name
end

Filtered_FW_Vector = FW_Vector(Signability, :);
Filtered_FW_FeatureMatrix = FW_FeatureMatrix(Signability, :);
%Filter the players out who are un-signable for that club

MedianClubStats = median(Club_Matrix, 1);
%Finding the median of each clubs normalised stats

Club = find(strcmp(Club_Vector.Squad, ClubName));
Club_Profile = Club_Matrix(Club, :);
%Match club to input

Stat_Strength = Club_Profile >= MedianClubStats
%Calculate stat strength based if its above or below the median
%(';'not inputted for visualisation of club's stats)

Strong_Stats = Filtered_FW_FeatureMatrix(:, Stat_Strength);
Weak_Stats = Filtered_FW_FeatureMatrix(:, ~Stat_Strength);
%Strong stats above median, weak below it

Strong_Club_Stats = Club_Profile(Stat_Strength);
Weak_Club_Stats = Club_Profile(~Stat_Strength);
%Apply same logic for clubs

Strong_Similarity = CosineSimilarity(Strong_Stats, Strong_Club_Stats);
Weak_GapPlugging = CosineSimilarity(Weak_Stats, Weak_Club_Stats);
%Calculate cosine similarity

Stat_Score = FinalScoreWeighting(Strong_Similarity, Weak_GapPlugging, Stat_Strength);
%Use inputs from FinalScoreWeighting script

ClubLeagueRow = strcmp(FW_Vector.Squad_DissData_FW, ClubName);
ClubLeague = FW_Vector.Comp(find(ClubLeagueRow, 1));
%Read club league and grab the first match (assumes each club has a forward
%(they should))

PlayerLeague = Filtered_FW_Vector.Comp;
PlayerMinutes = Filtered_FW_Vector.Min;
PlayerAge = Filtered_FW_Vector.Age;
%Define player league minute age stats

SameLeague = strcmp(PlayerLeague, ClubLeague);
NormalizedMinutes = PlayerMinutes / max(PlayerMinutes);
%Check for same and league, normalize minutes 0-1

AgeBoost = ones(height(Filtered_FW_Vector), 1);
%Create default age value

AgeBoost(PlayerAge >= 18 & PlayerAge <= 23) = 1.3;
AgeBoost(PlayerAge >= 24 & PlayerAge <= 27) = 1;
AgeBoost(PlayerAge >= 28 & PlayerAge <= 30) = 1.2;
AgeBoost(PlayerAge >= 31 & PlayerAge <= 32) = 1;
AgeBoost(PlayerAge >= 33) = 0.8;
%Boost multiplier based on age ranges

LeagueBoost = ones(height(Filtered_FW_Vector), 1);
%Create default league value

LeagueBoost(strcmp(Filtered_FW_Vector.Comp, 'eng Premier League')) = 1.25;
LeagueBoost(strcmp(Filtered_FW_Vector.Comp, 'es La Liga')) = 1.15;
LeagueBoost(strcmp(Filtered_FW_Vector.Comp, 'de Bundesliga')) = 1.1;
LeagueBoost(strcmp(Filtered_FW_Vector.Comp, 'it Serie A')) = 1.1;
LeagueBoost(strcmp(Filtered_FW_Vector.Comp, 'fr Ligue 1')) = 1;
%Boost multiplier based on league quality/difficulty

Signing_ClubTier = Club_Vector.ClubTier(Club);
%Interpret inputted clubs tier
FW_Hype_Factor = Calculate_FW_Hype(Filtered_FW_Vector, Signing_ClubTier);
%Input hype calculation

FW_Proven_Factor = Calculate_FW_Proven(Filtered_FW_Vector, Signing_ClubTier);
%Input proven calculation

SimilarityWeight = 0.9;
BoostWeight = 0.1;
%Weightings for stats vs boosts

BoostFactor = (1 + 0.05 * SameLeague + 0.2 * NormalizedMinutes .* AgeBoost .*LeagueBoost) .*FW_Hype_Factor .*FW_Proven_Factor;
%Define rules and weightings

Final_Score = SimilarityWeight * Stat_Score + BoostWeight * BoostFactor;
%Apply boost and weights to score

Final_Score = (Final_Score - min(Final_Score)) / (max(Final_Score) - min(Final_Score));
%Normalise final score

SameClub = strcmp(Filtered_FW_Vector.Squad_DissData_FW, ClubName);
Final_Score(SameClub) = -inf;
%Stops clubs signing their own players

Filtered_FW_Vector.FinalScore = Final_Score;
%Attatch weighting scores to table

SuggestionNumber = 20;
%Number of suggested players shown for the club based on similarity score

Sorted_Final_FW_Vector = sortrows(Filtered_FW_Vector, 'FinalScore', 'descend');
Top_FW_Suggestions = Sorted_Final_FW_Vector(1:SuggestionNumber, :);
%Sort top suggestions

Player = Top_FW_Suggestions.Player;
%Define players so likelihood can be implemented

Top_FW_Suggestions = SigningLikelihood_FWs(Top_FW_Suggestions, ClubName);
%Implement likelihood

Target_FW_ClubTier = FW_Vector.ClubTier;
%Define club tier of the forward target

FW_Fringe_Players = Suggest_FW_Fringe_Players(FW_Vector, Target_FW_ClubTier, Signing_ClubTier);
%Table for suggesting fringe players

if ~isempty(FW_Fringe_Players)
    writetable(FW_Fringe_Players, 'Suggested_Fringe_Forwards.csv');
    %Only write the table if the signing club is tier 4/5
end

Important_FW_Columns = {'Player', 'Pos', 'Squad_DissData_FW', 'Comp', 'Age', 'Min', 'Gls', 'Ast', 'G_A', 'xG', 'npxG_xAG', 'PrgC', 'SoT_', 'ValTiers', 'FinalScore', 'Unlikely_Label'};
%Create a list with only the most important columns
Top_FW_Suggestions_Display = Top_FW_Suggestions(:, Important_FW_Columns);
%Filter the table to only the columns needed

if any(strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'Pos'))
    Top_FW_Suggestions_Display.Properties.VariableNames{strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'Pos')} = 'Position';
end
%Changes Pos to Position in the table for readability

if any(strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'Squad_DissData_FW'))
    Top_FW_Suggestions_Display.Properties.VariableNames{strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'Squad_DissData_FW')} = 'Squad';
end
%Changes Squad_DissData_FW to Squad in the table for readability

if any(strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'Comp'))
    Top_FW_Suggestions_Display.Properties.VariableNames{strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'Comp')} = 'Competition';
end
%Changes Comp to Competition in the table for readability

if any(strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'Min'))
    Top_FW_Suggestions_Display.Properties.VariableNames{strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'Min')} = 'Minutes';
end
%Changes Min to Minutes in the table for readability

if any(strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'Gls'))
    Top_FW_Suggestions_Display.Properties.VariableNames{strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'Gls')} = 'Goals';
end
%Changes Gls to Goals in the table for readability

if any(strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'Ast'))
    Top_FW_Suggestions_Display.Properties.VariableNames{strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'Ast')} = 'Assists';
end
%Changes Ast to Assists in the table for readability

if any(strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'G_A'))
    Top_FW_Suggestions_Display.Properties.VariableNames{strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'G_A')} = 'G+A';
end
%Changes G_A to G+A in the table for readability

if any(strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'npxG_xAG'))
    Top_FW_Suggestions_Display.Properties.VariableNames{strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'npxG_xAG')} = 'npxG+xAG';
end
%Changes npxG_xAG to npxG+xAG in the table for readability

if any(strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'PrgC'))
    Top_FW_Suggestions_Display.Properties.VariableNames{strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'PrgC')} = 'ProgressiveCarries';
end
%Changes PrgC to ProgressiveCarries in the table for readability

if any(strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'SoT_'))
    Top_FW_Suggestions_Display.Properties.VariableNames{strcmp(Top_FW_Suggestions_Display.Properties.VariableNames, 'SoT_')} = 'SoT%';
end
%Changes SoT_ to SoT% in the table for readability

writetable(Top_FW_Suggestions_Display, 'Suggested_Forwards_Final.csv');
%Write the updated table

