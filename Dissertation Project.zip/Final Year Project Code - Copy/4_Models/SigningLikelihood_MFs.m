function [Top_MF_Suggestions] = SigningLikelihood_MFs(Top_MF_Suggestions, ClubName);
    
    Untouchable_MF = {'Pedri', 'Declan Rice', 'Jude Bellingham', 'Florian Wirtz', 'Jamal Musiala', 'Cole Palmer', 'Martin Ødegaard', 'Rodri', 'Joshua Kimmich', 'Federico Valverde'};
    %Lists Unlikely signings based on players being superstars
    
    Untouchable_MFs = ismember(Top_MF_Suggestions.Player, Untouchable_MF);
    %Puts them in a list

    Untouchable_Flag = Untouchable_MFs;
    %Flags unlikely signings for superstars

    Loyal_MF = {'Koke', 'Maximilian Arnold', 'Aleksandar Pavlovic', 'Luka Modrić', 'Dennis Geiger', 'Tom Cairney', 'Gavi', 'Kirian Rodríguez', 'Joshua Kimmich', 'Marc Casadó', 'Yannick Gerhardt', 'Yassine Kechta', 'Lewis Cook', 'Wilfred Ndidi', 'Pablo Barris', 'Curtis Jones', 'Lorenzo Pellegrini', 'Ryan Yates', 'Sean Longstaff'};
    %Lists Forwards who have been/are loyal to their club

    Loyal_MFs = ismember(Top_MF_Suggestions.Player, Loyal_MF);
    %Puts them in a lsit

    Loyal_Flag = Loyal_MFs;
    %Flags unlikely signings for loyal players

    RivalryPairs = {
        'Arsenal', 'Tottenham';
        'Real Madrid', 'Barcelona';
        'Manchester Utd', 'Liverpool';
        'Roma', 'Lazio';
        'Inter', 'Milan';
        'Paris S-G', 'Marseille';
        'Real Sociedad', 'Athletic Club';
        'Sevilla', 'Betis';
        'Fiorentina', 'Juventus';
        'Lyon', 'Saint-Étienne';
        };
    %Lists rivalries where players are unlikely to transfer between

    Rival_Flag = false(height(Top_MF_Suggestions), 1);
    %Set rival flag to default to false

    for i = 1:size(RivalryPairs, 1)
        ClubA = RivalryPairs{i, 1};
        ClubB = RivalryPairs{i, 2};
        %Interprets rival pairs as A and B

        Is_Rival = (strcmp(Top_MF_Suggestions.Squad_ClubTiers, ClubA) & strcmp(ClubName, ClubB)) | (strcmp(Top_MF_Suggestions.Squad_ClubTiers, ClubB) & strcmp(ClubName, ClubA));
        %Checks for transfer both ways between rival clubs

        Rival_Flag = Rival_Flag | Is_Rival;
        %Flag player if involved in transfer between rivals
    end

    Unlikely_Flag = Untouchable_Flag | Rival_Flag | Loyal_Flag;

    Top_MF_Suggestions.Unlikely_Label = repmat({''}, height(Top_MF_Suggestions), 1);
    %Adds a column in the table and lists if a signing is unlikely or not

    Top_MF_Suggestions.Unlikely_Label(Untouchable_Flag) = strcat(Top_MF_Suggestions.Unlikely_Label(Untouchable_Flag), '*Superstar');
    Top_MF_Suggestions.Unlikely_Label(Rival_Flag) = strcat(Top_MF_Suggestions.Unlikely_Label(Rival_Flag), '*Rival');
    Top_MF_Suggestions.Unlikely_Label(Loyal_Flag) = strcat(Top_MF_Suggestions.Unlikely_Label(Loyal_Flag), '*Loyal');
    %Writes in reasons for a potential unlikely signing
end


