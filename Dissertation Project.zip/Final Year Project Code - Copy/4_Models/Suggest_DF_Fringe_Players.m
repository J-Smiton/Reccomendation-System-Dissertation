function DF_Fringe_Players = Suggest_DF_Fringe_Players(DF_Vector, Target_DF_ClubTier, Signing_ClubTier);

    Target_DF_ClubTier = DF_Vector.ClubTier;
    %Specify variable for club of players being suggested
    Fringe_DF_Minutes = DF_Vector.Min;
    %Specify variable for minutes of fringe players

    DF_Fringe_Players = table();
    %Create a table of fringe players

    Non_Fringe_Players = {'David Alaba', 'Ronald Araújo', 'Sven Botman', 'Patrick Dorgu', 'Ayden Heaven', 'Lloyd Kelly', 'Presnel Kimpembe', 'Mohamed Simakan', 'Milan Škriniar'};
    %Create a list of notable exceptions (for injuries and Jnauary
    %transfers)

    if Signing_ClubTier >= 4
    %Only for tier 4 and 5 clubs
        DF_Fringe_Targets = Target_DF_ClubTier <= 2;
        %Suggest tier 1+2 players
        Fringe_MFs = Fringe_DF_Minutes <= 500;
        %Who have 500 or less minutes
        Eligible_Fringe_DFs = Fringe_MFs & DF_Fringe_Targets;
        %Eligible for a fringe signing if they're tier1/2 and have <500 min
        DF_Fringe_Players = DF_Vector(Eligible_Fringe_DFs, :);
        %Create variable holding fringe players
        Excluded_DFs = ismember(DF_Fringe_Players.Player, Non_Fringe_Players);
        %Implement exclusions 
        DF_Fringe_Players(Excluded_DFs, :) = [];
        %Minus excluded defenders

        Opportunity_Label = repmat("Fringe Transfer", height(DF_Fringe_Players), 1);
        %Add 'fringe players' to opportunity label for players over 23
        Opportunity_Label(DF_Fringe_Players.Age <= 23) = "Loan Opportunity";
        %Add 'loan opportunity' to players 23 and under
        DF_Fringe_Players.Opportunity = Opportunity_Label;
        %Apply label with description of potential signing

        DF_Fringe_Players = sortrows(DF_Fringe_Players, 'Rk');
        %Sort players by their 'Rk' (Rank)-Alphabetical
    else
        DF_Fringe_Players = table();
        %Empty table for tier 1, 2 and 3 clubs
    end 
end
