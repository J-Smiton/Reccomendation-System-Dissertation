function MF_Proven_Factor = Calculate_MF_Proven(Filtered_MF_Vector, Signing_ClubTier);

    MF_Proven_Tier1 = {'Joshua Kimmich', 'Martin Ødegaard', 'Nicolò Barella', 'Hakan Çalhanoğlu', 'Frenkie De Jong', 'Bruno Fernandes'};
    MF_Proven_Tier2 = {'Bruno Guimarães', 'Tijjani Reijnders', 'Leon Goretzka', 'Youri Tielemans', 'Alexis Mac Allister', 'Bernardo Silva', 'Dani Olmo', 'Lucas Paquetá'};
    MF_Proven_Tier3 = {'Mikel Merino', 'Fabián Ruiz', 'Joelinton', 'João Palhinha', 'Douglas Luiz', 'John McGinn', 'Alex Iwobi', 'Manuel Locatelli', 'Rodrigo De Paul', 'Stanislav Lobotka'};
    %Ranking players by their past achievements (performances stats
    %trophies etc.)

    MF_Proven_Factor = ones(height(Filtered_MF_Vector), 1);
    %Set default multiplier to 1

    if Signing_ClubTier <= 2
        for i = 1:height(Filtered_MF_Vector)
        %Tier 1 and 2 clubs recommended proven players
        
            PlayerName = Filtered_MF_Vector.Player{i};
            %For loop checks player name every iteration

            if ismember(PlayerName, MF_Proven_Tier1)
                MF_Proven_Factor(i) = 1.5;
            elseif ismember(PlayerName, MF_Proven_Tier2)
                MF_Proven_Factor(i) = 1.35;
            elseif ismember(PlayerName, MF_Proven_Tier3)
                MF_Proven_Factor(i) = 1.15;
                %Apply 1.5x to tier1 hype, 1.35x to tier2 hype and 1.15x to tier3                
            end
        end
    end
end