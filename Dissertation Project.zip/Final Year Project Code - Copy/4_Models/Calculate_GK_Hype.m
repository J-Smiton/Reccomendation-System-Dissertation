function GK_Hype_Factor = Calculate_GK_Hype(Filtered_GK_Vector, Signing_ClubTier);

    GK_Hype_Tier1 = {'Joan García', 'David Raya', 'Bart Verbruggen', 'Mike Maignan'};
    GK_Hype_Tier2 = {'Emiliano Martínez', 'Giorgi Marmadashvili', 'Marco Canesecchi', 'Marcin Bulka'};
    GK_Hype_Tier3 = {'Dean Henderson', 'Vanja Milinković-Savić', 'Matz Sels', 'Lucas Chevalier'};
    %Listing 4 players by their hype on the transfer market

    GK_Hype_Factor = ones(height(Filtered_GK_Vector), 1);
    %Set default multiplier to 1

    if Signing_ClubTier <= 2
        for i = 1:height(Filtered_GK_Vector)
        %Tier 1 and 2 clubs recommended 'hype' players
        
            PlayerName = Filtered_GK_Vector.Player{i};
            %For loop checks player name every iteration

            if ismember(PlayerName, GK_Hype_Tier1)
                GK_Hype_Factor(i) = 1.65;
            elseif ismember(PlayerName, GK_Hype_Tier2)
                GK_Hype_Factor(i) = 1.45;
            elseif ismember(PlayerName, GK_Hype_Tier3)
                GK_Hype_Factor(i) = 1.25;
                %Apply 1.65x to tier1 hype, 1.45x to tier2 hype and 1.25x to tier3
            end
        end
    end
end