MF_Vector = readtable('Norm_DissData_MF_Val_Final.csv');
%Load normalised midfielder data
MF_Features = ["xAG_norm", "PrgC_norm", "PrgP_norm", "Cmp__norm", "TotDist_norm", "PrgDist_norm", "TB_norm", "Tkl_Int_norm", "Rec_norm", "Recov_norm"];
%Add chosen stats to feature list
MF_FeatureMatrix = MF_Vector{:, MF_Features};
%Implement this into the feature matrix

Club_Vector = readtable('Norm_finalTeamStats.csv');
%Load normalised club data
Club_Features = ["Ttl_xAG_norm", "Ttl_PrgC_norm", "Ttl_PrgP_norm", "Avg_Cmp__norm", "Ttl_TotDist_norm", "Ttl_PrgDist_norm", "Ttl_TB_norm", "Ttl_Tkl_Int_norm", "Ttl_Rec_norm", "Ttl_Recov_norm"];
%Add the same stats to feature list
Club_Matrix = Club_Vector{:, Club_Features};
%Implement this into the feature matrix
Club_Profile = Club_Matrix(1, :);
%Set this up as the club profile

ClubName = GetClubName()
%Take ClubName from UI dropdown
Club = strcmp(Club_Vector.Squad, ClubName);
%Compare inputted club with those in the club vector

if any (Club)
    ClubTier = Club_Vector.ClubTier(Club);
    %If there is a club match then apply signability rule
    Signability = MF_Vector.ValTier >= (ClubTier - 1) & MF_Vector.ValTier <= ClubTier;
    %Club can sign 1 val tier higher or any below/same
else
    error('Club not found, check list for how to input Club Names!');
    %Error if there is no matching club name
end

Filtered_MF_Vector = MF_Vector(Signability, :);
Filtered_MF_FeatureMatrix = MF_FeatureMatrix(Signability, :);
%Filter the players out who are un-signable for that club

MedianClubStats = median(Club_Matrix, 1);
%Finding the median of each clubs normalised stats

Club = find(strcmp(Club_Vector.Squad, ClubName));
Club_Profile = Club_Matrix(Club, :);
%Match club to input

Stat_Strength = Club_Profile >= MedianClubStats
%Calculate stat strength based if its above or below the median
%(';'not inputted for visualisation of club's stats)

Strong_Stats = Filtered_MF_FeatureMatrix(:, Stat_Strength);
Weak_Stats = Filtered_MF_FeatureMatrix(:, ~Stat_Strength);
%Strong stats above median, weak below it

Strong_Club_Stats = Club_Profile(Stat_Strength);
Weak_Club_Stats = Club_Profile(~Stat_Strength);
%Apply same logic for clubs

Strong_Similarity = CosineSimilarity(Strong_Stats, Strong_Club_Stats);
Weak_GapPlugging = CosineSimilarity(Weak_Stats, Weak_Club_Stats);
%Calculate cosine similarity

Stat_Score = FinalScoreWeighting(Strong_Similarity, Weak_GapPlugging, Stat_Strength);
%Use inputs from FinalScoreWeighting script

ClubLeagueRow = strcmp(MF_Vector.Squad_ClubTiers, ClubName);
ClubLeague = MF_Vector.Comp(find(ClubLeagueRow, 1));
%Read club league and grab the first match (assumes each club has a
%midfielder (they should))

PlayerLeague = Filtered_MF_Vector.Comp;
PlayerMinutes = Filtered_MF_Vector.Min;
PlayerAge = Filtered_MF_Vector.Age;
%Define player league minute age stats

SameLeague = strcmp(PlayerLeague, ClubLeague);
NormalizedMinutes = PlayerMinutes / max(PlayerMinutes);
%Check for same and league, normalize minutes 0-1

AgeBoost = ones(height(Filtered_MF_Vector), 1);
%Create default age value

AgeBoost(PlayerAge >= 18 & PlayerAge <= 23) = 1.3;
AgeBoost(PlayerAge >= 24 & PlayerAge <= 27) = 1;
AgeBoost(PlayerAge >= 28 & PlayerAge <= 30) = 1.2;
AgeBoost(PlayerAge >= 31 & PlayerAge <= 32) = 1;
AgeBoost(PlayerAge >= 33) = 0.8;
%Boost multiplier based on age ranges

LeagueBoost = ones(height(Filtered_MF_Vector), 1);
%Create default league value

LeagueBoost(strcmp(Filtered_MF_Vector.Comp, 'eng Premier League')) = 1.25;
LeagueBoost(strcmp(Filtered_MF_Vector.Comp, 'es La Liga')) = 1.15;
LeagueBoost(strcmp(Filtered_MF_Vector.Comp, 'de Bundesliga')) = 1.1;
LeagueBoost(strcmp(Filtered_MF_Vector.Comp, 'it Serie A')) = 1.1;
LeagueBoost(strcmp(Filtered_MF_Vector.Comp, 'fr Ligue 1')) = 1;
%Boost multiplier based on league quality/difficulty

Signing_ClubTier = Club_Vector.ClubTier(Club);
%Interpret inputted clubs tier
MF_Hype_Factor = Calculate_MF_Hype(Filtered_MF_Vector, Signing_ClubTier);
%Input hype calculation

MF_Proven_Factor = Calculate_MF_Proven(Filtered_MF_Vector, Signing_ClubTier);
%Input proven calculation

SimilarityWeight = 0.9;
BoostWeight = 0.1;
%Weightings for stats vs boosts

BoostFactor = (1 + 0.05 * SameLeague + 0.2 * NormalizedMinutes .* AgeBoost .*LeagueBoost) .*MF_Hype_Factor .*MF_Proven_Factor;
%Define rules and weightings

Final_Score = SimilarityWeight * Stat_Score + BoostWeight * BoostFactor;
%Apply boost and weights to score

Final_Score = (Final_Score - min(Final_Score)) / (max(Final_Score) - min(Final_Score));
%Normalise final score

SameClub = strcmp(Filtered_MF_Vector.Squad_ClubTiers, ClubName);
Final_Score(SameClub) = -inf;
%Stops clubs signing their own players

Filtered_MF_Vector.FinalScore = Final_Score;
%Attatch weighting scores to table

SuggestionNumber = 20;
%Number of suggested players shown for the club based on similarity score

Sorted_Final_MF_Vector = sortrows(Filtered_MF_Vector, 'FinalScore', 'descend');
Top_MF_Suggestions = Sorted_Final_MF_Vector(1:SuggestionNumber, :);
%Sort top suggestions

Player = Top_MF_Suggestions.Player;
%Define players so likelihood can be implemented

Top_MF_Suggestions = SigningLikelihood_MFs(Top_MF_Suggestions, ClubName);
%Implement likelihood

Target_MF_ClubTier = MF_Vector.ClubTier;
%Define club tier of the midfield target

MF_Fringe_Players = Suggest_MF_Fringe_Players(MF_Vector, Target_MF_ClubTier, Signing_ClubTier);
%Table for suggesting fringe players

if ~isempty(MF_Fringe_Players)
    writetable(MF_Fringe_Players, 'Suggested_Fringe_Midfielders.csv');
    %Only write the table if the signing club is tier 4/5
end

Important_MF_Columns = {'Player', 'Pos', 'Squad_DissData_MF', 'Comp', 'Age', 'Min', 'xAG', 'PrgC', 'PrgP', 'Cmp_', 'TotDist', 'PrgDist', 'TB', 'Tkl_Int', 'Rec', 'Recov',  'ValTier', 'FinalScore', 'Unlikely_Label'};
%Create a list with only the most important columns
Top_MF_Suggestions_Display = Top_MF_Suggestions(:, Important_MF_Columns);
%Filter the table to only the columns needed

if any(strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'Pos'))
    Top_MF_Suggestions_Display.Properties.VariableNames{strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'Pos')} = 'Position';
end
%Changes Pos to Position in the table for readability

if any(strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'Squad_DissData_MF'))
    Top_MF_Suggestions_Display.Properties.VariableNames{strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'Squad_DissData_MF')} = 'Squad';
end
%Changes Squad_DissData_MF to Squad in the table for readability

if any(strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'Comp'))
    Top_MF_Suggestions_Display.Properties.VariableNames{strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'Comp')} = 'Competition';
end
%Changes Comp to Competition in the table for readability

if any(strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'Min'))
    Top_MF_Suggestions_Display.Properties.VariableNames{strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'Min')} = 'Minutes';
end
%Changes Min to Minutes in the table for readability

if any(strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'PrgC'))
    Top_MF_Suggestions_Display.Properties.VariableNames{strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'PrgC')} = 'ProgressiveCarries';
end
%Changes PrgC to ProgressiveCarries in the table for readability

if any(strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'Prgp'))
    Top_MF_Suggestions_Display.Properties.VariableNames{strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'PrgP')} = 'ProgressivePasses';
end
%Changes PrgP to ProgressivePasses in the table for readability

if any(strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'Cmp_'))
    Top_MF_Suggestions_Display.Properties.VariableNames{strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'Cmp_')} = 'PassCompletion(%)';
end
%Changes Cmp_ to PassCompletion(%) in the table for readability

if any(strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'TotDist'))
    Top_MF_Suggestions_Display.Properties.VariableNames{strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'TotDist')} = 'TotalDistance';
end
%Changes TotDist to TotalDistance in the table for readability

if any(strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'PrgDist'))
    Top_MF_Suggestions_Display.Properties.VariableNames{strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'PrgDist')} = 'ProgressiveDistance';
end
%Changes PrgDist to ProgressiveDistance in the table for readability

if any(strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'TB'))
    Top_MF_Suggestions_Display.Properties.VariableNames{strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'TB')} = 'ThroughBalls';
end
%Changes TB to ThroughBalls in the table for readability

if any(strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'Tkl_Int'))
    Top_MF_Suggestions_Display.Properties.VariableNames{strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'Tkl_Int')} = 'Tackles+Interceptions';
end
%Changes Tkl_Int to Tackles+Interceptions in the table for readability

if any(strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'Rec'))
    Top_MF_Suggestions_Display.Properties.VariableNames{strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'Rec')} = 'Recieved(Passes)';
end
%Changes Rec to Recieved(Passes) in the table for readability

if any(strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'Recov'))
    Top_MF_Suggestions_Display.Properties.VariableNames{strcmp(Top_MF_Suggestions_Display.Properties.VariableNames, 'Recov')} = 'Recoveries';
end
%Changes Recov to Recoveries in the table for readability

writetable(Top_MF_Suggestions_Display, 'Suggested_Midfielders_Final.csv');
%Write the updated table

