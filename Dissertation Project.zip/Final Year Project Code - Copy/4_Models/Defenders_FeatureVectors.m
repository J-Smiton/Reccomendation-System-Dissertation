DF_Vector = readtable('Norm_DissData_DF_Val_Final.csv');
%Load normalised defender data
DF_Features = ["xAG_norm", "Def3rd_norm", "Tkl__norm", "Tkl_Int_norm", "Clr_norm", "Recov_norm"];
%Add chosen stats to feature list
DF_FeatureMatrix = DF_Vector{:, DF_Features};
%Implement this into the feature matrix

Club_Vector = readtable('Norm_finalTeamStats.csv');
%Load normalised club data
Club_Features = ["Ttl_xAG_norm", "Ttl_Def3rd_norm", "Avg_Tkl__norm", "Ttl_Clr_norm", "Ttl_Tkl_Int_norm", "Ttl_Recov_norm"];
%Add the same stats to feature list
Club_Matrix = Club_Vector{:, Club_Features};
%Implement this into the feature matrix
Club_Profile = Club_Matrix(1, :);
%Set this up as the club profile

ClubName = GetClubName()
%Take ClubName from UI dropdown
Club = strcmp(Club_Vector.Squad, ClubName);
%Compare inputted club with those in the club vector

if any (Club)
    ClubTier = Club_Vector.ClubTier(Club);
    %If there is a club match then apply signability rule
    Signability = DF_Vector.ValTiers >= (ClubTier - 1) & DF_Vector.ValTiers <= ClubTier;
    %Club can sign 1 val tier higher or any below/same
else
    error('Club not found, check list for how to input Club Names!');
    %Error if there is no matching club name
end

Filtered_DF_Vector = DF_Vector(Signability, :);
Filtered_DF_FeatureMatrix = DF_FeatureMatrix(Signability, :);
%Filter the players out who are un-signable for that club

MedianClubStats = median(Club_Matrix, 1);
%Finding the median of each clubs normalised stats

Club = find(strcmp(Club_Vector.Squad, ClubName));
Club_Profile = Club_Matrix(Club, :);
%Match club to input

Stat_Strength = Club_Profile >= MedianClubStats
%Calculate stat strength based if its above or below the median
%(';'not inputted for visualisation of club's stats)

Strong_Stats = Filtered_DF_FeatureMatrix(:, Stat_Strength);
Weak_Stats = Filtered_DF_FeatureMatrix(:, ~Stat_Strength);
%Strong stats above median, weak below it

Strong_Club_Stats = Club_Profile(Stat_Strength);
Weak_Club_Stats = Club_Profile(~Stat_Strength);
%Apply same logic for clubs

Strong_Similarity = CosineSimilarity(Strong_Stats, Strong_Club_Stats);
Weak_GapPlugging = CosineSimilarity(Weak_Stats, Weak_Club_Stats);
%Calculate cosine similarity

Stat_Score = FinalScoreWeighting(Strong_Similarity, Weak_GapPlugging, Stat_Strength);
%Use inputs from FinalScoreWeighting script

ClubLeagueRow = strcmp(DF_Vector.Squad_DissData_DF, ClubName);
ClubLeague = DF_Vector.Comp(find(ClubLeagueRow, 1));
%Read club league and grab the first match (assumes each club has a
%defender (they should))

PlayerLeague = Filtered_DF_Vector.Comp;
PlayerMinutes = Filtered_DF_Vector.Min;
PlayerAge = Filtered_DF_Vector.Age;
%Define player league minute age stats

SameLeague = strcmp(PlayerLeague, ClubLeague);
NormalizedMinutes = PlayerMinutes / max(PlayerMinutes);
%Check for same and league, normalize minutes 0-1

AgeBoost = ones(height(Filtered_DF_Vector), 1);
%Create default age value

AgeBoost(PlayerAge >= 18 & PlayerAge <= 23) = 1.3;
AgeBoost(PlayerAge >= 24 & PlayerAge <= 27) = 1;
AgeBoost(PlayerAge >= 28 & PlayerAge <= 30) = 1.2;
AgeBoost(PlayerAge >= 31 & PlayerAge <= 32) = 1;
AgeBoost(PlayerAge >= 33) = 0.8;
%Boost multiplier based on age ranges

LeagueBoost = ones(height(Filtered_DF_Vector), 1);
%Create default league value

LeagueBoost(strcmp(Filtered_DF_Vector.Comp, 'eng Premier League')) = 1.25;
LeagueBoost(strcmp(Filtered_DF_Vector.Comp, 'es La Liga')) = 1.15;
LeagueBoost(strcmp(Filtered_DF_Vector.Comp, 'de Bundesliga')) = 1.1;
LeagueBoost(strcmp(Filtered_DF_Vector.Comp, 'it Serie A')) = 1.1;
LeagueBoost(strcmp(Filtered_DF_Vector.Comp, 'fr Ligue 1')) = 1;
%Boost multiplier based on league quality/difficulty

Signing_ClubTier = Club_Vector.ClubTier(Club);
%Interpret inputted clubs tier
DF_Hype_Factor = Calculate_DF_Hype(Filtered_DF_Vector, Signing_ClubTier);
%Input hype calculation

DF_Proven_Factor = Calculate_DF_Proven(Filtered_DF_Vector, Signing_ClubTier);
%Input proven calculation

SimilarityWeight = 0.9;
BoostWeight = 0.1;
%Weightings for stats vs boosts

BoostFactor = (1 + 0.05 * SameLeague + 0.2 * NormalizedMinutes .* AgeBoost .*LeagueBoost) .*DF_Hype_Factor .*DF_Proven_Factor;
%Define rules and weightings

Final_Score = SimilarityWeight * Stat_Score + BoostWeight * BoostFactor;
%Apply boost and weights to score

Final_Score = (Final_Score - min(Final_Score)) / (max(Final_Score) - min(Final_Score));
%Normalise final score

SameClub = strcmp(Filtered_DF_Vector.Squad_ClubTiers, ClubName);
Final_Score(SameClub) = -inf;
%Stops clubs signing their own players

Filtered_DF_Vector.FinalScore = Final_Score;
%Attatch weighting scores to table

SuggestionNumber = 20;
%Number of suggested players shown for the club based on similarity score

Sorted_Final_DF_Vector = sortrows(Filtered_DF_Vector, 'FinalScore', 'descend');
Top_DF_Suggestions = Sorted_Final_DF_Vector(1:SuggestionNumber, :);
%Sort top suggestions

Player = Top_DF_Suggestions.Player;
%Define players so likelihood can be implemented

Top_DF_Suggestions = SigningLikelihood_DFs(Top_DF_Suggestions, ClubName);
%Implement likelihood

Target_DF_ClubTier = DF_Vector.ClubTier;
%Define club tier of the defender target

DF_Fringe_Players = Suggest_DF_Fringe_Players(DF_Vector, Target_DF_ClubTier, Signing_ClubTier);
%Table for suggesting fringe players

if ~isempty(DF_Fringe_Players)
    writetable(DF_Fringe_Players, 'Sugested_Fringe_Defenders.csv');
    %Only write the table if the signing club is tier 4/5
end

Important_DF_Columns = {'Player', 'Pos', 'Squad_DissData_DF', 'Comp', 'Age', 'Min', 'xAG', 'Def3rd', 'Tkl_', 'Tkl_Int', 'Recov',  'ValTiers', 'FinalScore', 'Unlikely_Label'};
%Create a list with only the most important columns
Top_DF_Suggestions_Display = Top_DF_Suggestions(:, Important_DF_Columns);
%Filter the table to only the columns needed

if any(strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Pos'))
    Top_DF_Suggestions_Display.Properties.VariableNames{strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Pos')} = 'Position';
end
%Changes Pos to Position in the table for readability

if any(strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Squad_DissData_DF'))
    Top_DF_Suggestions_Display.Properties.VariableNames{strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Squad_DissData_DF')} = 'Squad';
end
%Changes Squad_DissData_DF to Squad in the table for readability

if any(strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Comp'))
    Top_DF_Suggestions_Display.Properties.VariableNames{strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Comp')} = 'Competition';
end
%Changes Comp to Competition in the table for readability

if any(strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Min'))
    Top_DF_Suggestions_Display.Properties.VariableNames{strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Min')} = 'Minutes';
end
%Changes Min to Minutes in the table for readability

if any(strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Def3rd'))
    Top_DF_Suggestions_Display.Properties.VariableNames{strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Def3rd')} = 'Defensive3rd Tackles';
end
%Changes Def3rd to Defensive3rd Tackles in the table for readability

if any(strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Tkl_'))
    Top_DF_Suggestions_Display.Properties.VariableNames{strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Tkl_')} = 'Tackle%';
end
%Changes Tkl_ to Tackle% in the table for readability

if any(strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Tkl_Int'))
    Top_DF_Suggestions_Display.Properties.VariableNames{strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Tkl_Int')} = 'Tackles+Interceptions';
end
%Changes Tkl_Int to Tackles+Interceptions in the table for readability

if any(strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Clr'))
    Top_DF_Suggestions_Display.Properties.VariableNames{strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Clr')} = 'Clearances';
end
%Changes Clr to Clearances in the table for readability

if any(strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Recov'))
    Top_DF_Suggestions_Display.Properties.VariableNames{strcmp(Top_DF_Suggestions_Display.Properties.VariableNames, 'Recov')} = 'Recoveries';
end
%Changes Recov to Recoveries in the table for readability

writetable(Top_DF_Suggestions_Display, 'Suggested_Defenders_Final.csv');
%Write the updated table
