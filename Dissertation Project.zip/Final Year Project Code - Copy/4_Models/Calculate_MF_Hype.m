function MF_Hype_Factor = Calculate_MF_Hype(Filtered_MF_Vector, Signing_ClubTier);

    MF_Hype_Tier1 = {'Jude Bellingham', 'Florian Wirtz', 'Morgan Gibbs-White', 'Xavi Simons', 'João Neves', 'Martín Zubimendi', 'Eberechie Eze', 'Morgan Rogers'};
    MF_Hype_Tier2 = {'Dominik Szoboszlai', 'Oihan Sancet', 'Eduardo Camavinga', 'Aurélien Tchouaméni', 'Bruno Guimarães', 'Nicolò Barella', 'Tijjani Reijnders', 'Fermín López'};
    MF_Hype_Tier3 = {'Charles De Ketelaere', 'Sandro Tonali', 'Scott McTominay', 'Pablo Barrios', 'James Maddison', 'Kobbie Mainoo', 'Hugo Larsson', 'Adam Wharton'};
    %Listing 8 players by their hype on the transfer market

    MF_Hype_Factor = ones(height(Filtered_MF_Vector), 1);
    %Set default multiplier to 1

    if Signing_ClubTier <= 2
        for i = 1:height(Filtered_MF_Vector)
        %Tier 1 and 2 clubs recommended 'hype' players
        
            PlayerName = Filtered_MF_Vector.Player{i};
            %For loop checks player name every iteration

            if ismember(PlayerName, MF_Hype_Tier1)
                MF_Hype_Factor(i) = 1.65;
            elseif ismember(PlayerName, MF_Hype_Tier2)
                MF_Hype_Factor(i) = 1.45;
            elseif ismember(PlayerName, MF_Hype_Tier3)
                MF_Hype_Factor(i) = 1.25;
                %Apply 1.65x to tier1 hype, 1.45x to tier2 hype and 1.25x to tier3
            end
        end
    end
end