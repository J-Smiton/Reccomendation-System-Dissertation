function [Stat_Score] = FinalScoreWeighting(Strong_Similarity, Weak_GapPlugging, Stat_Strength) 
    
    Strong_Weight = sum(Stat_Strength) / length(Stat_Strength);
    %Suggest players who allign with stats for metrics the club excels in
    %(is above the median in)
    Weak_Weight = 1 - Strong_Weight;
    %Suggets players who differentiate with stats for metrics the club
    %struggles with (is below the median in)
    Stat_Score = Strong_Weight * Strong_Similarity + Weak_Weight * Weak_GapPlugging;
    %Combine this into stat score
end