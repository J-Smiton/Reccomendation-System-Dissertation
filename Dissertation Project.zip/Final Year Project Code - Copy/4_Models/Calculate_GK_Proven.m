function GK_Proven_Factor = Calculate_GK_Proven(Filtered_GK_Vector, Signing_ClubTier);

    GK_Proven_Tier1 = {'Thibaut Courtois', 'Alisson Becker', 'Marc-André ter Stegen', 'Jan Oblak', 'Gianluigi Donnarumma', 'Emiliano Martínez', 'Ederson'};
    GK_Proven_Tier2 = {'David Raya', 'Gregor Kobel', 'Wojciech Szczesny', 'David De Gea', 'Yann Sommer', 'Unai Simón', 'Giorgi Marmadashvili', 'Maueal Neuer'};
    GK_Proven_Tier3 = {'Jordan Pickford', 'Nick Pope', 'Lukas Hradecky', 'Bernd Leno', 'Matz Sels', 'Joan García'};
    %Listing players by their past achievements (performances stats
    %trophies etc.)

    GK_Proven_Factor = ones(height(Filtered_GK_Vector), 1);
    %Set default multiplier to 1

    if Signing_ClubTier <= 2
        for i = 1:height(Filtered_GK_Vector)
        %Tier 1 and 2 clubs recommended proven players
        
            PlayerName = Filtered_GK_Vector.Player{i};
            %For loop checks player name every iteration

            if ismember(PlayerName, GK_Proven_Tier1)
                GK_Proven_Factor(i) = 1.5;
            elseif ismember(PlayerName, GK_Proven_Tier2)
                GK_Proven_Factor(i) = 1.35;
            elseif ismember(PlayerName, GK_Proven_Tier3)
                GK_Proven_Factor(i) = 1.15;
                %Apply 1.5x to tier1 hype, 1.35x to tier2 hype and 1.15x to tier3                
            end
        end
    end
end