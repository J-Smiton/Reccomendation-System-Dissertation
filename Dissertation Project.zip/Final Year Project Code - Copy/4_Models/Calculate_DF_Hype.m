function DF_Hype_Factor = Calculate_DF_Hype(Filtered_DF_Vector, Signing_ClubTier);

    DF_Hype_Tier1 = {'Alessandro Bastoni', 'Alejandro Balde', 'William Saliba', 'Dean Huijsen', 'Piero Hincapié', 'Ibrahima Konaté', 'Jeremie Frimpong', 'Marc Guéhi'};
    DF_Hype_Tier2 = {'Leny Yoro', 'Theo Hernández', 'Castello Lukeba', 'Jarrad Branthwaite', 'Micky Van De Ven', 'Ben White', 'Milos Kerkez', 'Nico Schlotterbeck'};
    DF_Hype_Tier3 = {'Riccardo Calafiori', 'Alejandro Grimaldo', 'Ian Maatsen', 'Rico Lewis', 'Diogo Dalot', 'Levi Colwill', 'Ilya Zabarnyi', 'Giorgio Scalvini'};
    %Listing 8 players by their hype on the transfer market

    DF_Hype_Factor = ones(height(Filtered_DF_Vector), 1);
    %Set default multiplier to 1

    if Signing_ClubTier <= 2
        for i = 1:height(Filtered_DF_Vector)
        %Tier 1 and 2 clubs recommended 'hype' players
        
            PlayerName = Filtered_DF_Vector.Player{i};
            %For loop checks player name every iteration

            if ismember(PlayerName, DF_Hype_Tier1)
                DF_Hype_Factor(i) = 1.65;
            elseif ismember(PlayerName, DF_Hype_Tier2)
                DF_Hype_Factor(i) = 1.45;
            elseif ismember(PlayerName, DF_Hype_Tier3)
                DF_Hype_Factor(i) = 1.25;
                %Apply 1.65x to tier1 hype, 1.45x to tier2 hype and 1.25x to tier3
            end
        end
    end
end