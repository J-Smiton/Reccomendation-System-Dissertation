function FW_Fringe_Players = Suggest_FW_Fringe_Players(FW_Vector, Target_FW_ClubTier, Signing_ClubTier);

    Target_FW_ClubTier = FW_Vector.ClubTier;
    %Specify variable for club of players being sugested
    Fringe_FW_Minutes = FW_Vector.Min;
    %Specify variable for minutes of fringe players

    FW_Fringe_Players = table();
    %Create a table of fringe players

    Non_Fringe_Players = {'Donyell Malen', 'Richarlison', 'Randal Kolo Muani', 'Mathys Tel', 'Marcus Rashford'};
    %Create a list of notable exceptions (for injuries and Jnauary
    %transfers)

    if Signing_ClubTier >= 4
    %Only for tier 4 and 5 clubs
        FW_Fringe_Targets = Target_FW_ClubTier <= 2;
        %Suggest tier 1+2 players
        Fringe_FWs = Fringe_FW_Minutes <= 500;
        %Who have 500 or less minutes
        Eligible_Fringe_FWs = Fringe_FWs & FW_Fringe_Targets;
        %Eligible for a fringe signing if they're tier1/2 and have <500 min
        FW_Fringe_Players = FW_Vector(Eligible_Fringe_FWs, :);
        %Create variable holding fringe players
        Excluded_FWs = ismember(FW_Fringe_Players.Player, Non_Fringe_Players);
        %Implement exclusions 
        FW_Fringe_Players(Excluded_FWs, :) = [];
        %Minus excluded forwards

        Opportunity_Label = repmat("Fringe Transfer", height(FW_Fringe_Players), 1);
        %Add 'fringe players' to opportunity label for players over 23
        Opportunity_Label(FW_Fringe_Players.Age <= 23) = "Loan Opportunity";
        %Add 'loan opportunity' to players 23 and under
        FW_Fringe_Players.Opportunity = Opportunity_Label;
        %Apply label with description of potential signing

        FW_Fringe_Players = sortrows(FW_Fringe_Players, 'Rk');
        %Sort players by their 'Rk' (Rank)-Alphabetical
    else
        FW_Fringe_Players = table();
        %Empty table for tier 1, 2 and 3 clubs
    end 
end








