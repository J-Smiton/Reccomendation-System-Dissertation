function scores = CosineSimilarity(A, B)
%function stating cosine similarity between player and club vectors

    %%numerators = sum(A .* B, 2);
    numerators = A * B';
    %Computes the dot product of each row in A and B
    A_Norms = sqrt(sum(A.^2, 2));
    %Computes Euclidean norm of each player in player vector
    B_Norm = norm(B);
    %Computes Euclidean norm of the club in the club vector
    denominator = A_Norms * B_Norm;
    denominator(denominator == 0) = eps;
    %Replaces any 0  with eps(2.2203e-16 to be exact)
    scores = numerators ./ denominator;
    %Computes dot product divided by dot product of euclidean norms
end



