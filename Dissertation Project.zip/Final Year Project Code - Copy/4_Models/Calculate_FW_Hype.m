function FW_Hype_Factor = Calculate_FW_Hype(Filtered_FW_Vector, Signing_ClubTier);

    FW_Hype_Tier1 = {'Lautaro Martinez', 'Raphinha', 'Alexander Isak', 'Rodrygo', 'Rafael Leao', 'Julián Alvarez', 'Michael Olise', 'Anthony Gordon'};
    FW_Hype_Tier2 = {'Benjamin Sesko', 'Hugo Ekitiké', 'Loïs Openda', 'Nico Williams', 'Bryan Mbuemo', 'Ollie Watkins', 'Marcus Thuram', 'João Pedro'};
    FW_Hype_Tier3 = {'Jamie Gittens', 'Mohammed Kudus', 'Antoine Semenyo', 'Mateo Retegui', 'Victor Boniface', 'Nicolas Jackson', 'Karim Adeyemi', 'Ademola Lookman'};
    %Listing 8 players by their hype on the transfer market

    FW_Hype_Factor = ones(height(Filtered_FW_Vector), 1);
    %Set default multiplier to 1

    if Signing_ClubTier <= 2
        for i = 1:height(Filtered_FW_Vector)
        %Tier 1 and 2 clubs recommended 'hype' players
        
            PlayerName = Filtered_FW_Vector.Player{i};
            %For loop checks player name every iteration

            if ismember(PlayerName, FW_Hype_Tier1)
                FW_Hype_Factor(i) = 1.65;
            elseif ismember(PlayerName, FW_Hype_Tier2)
                FW_Hype_Factor(i) = 1.45;
            elseif ismember(PlayerName, FW_Hype_Tier3)
                FW_Hype_Factor(i) = 1.25;
                %Apply 1.65x to tier1 hype, 1.45x to tier2 hype and 1.25x to tier3
            end
        end
    end
end