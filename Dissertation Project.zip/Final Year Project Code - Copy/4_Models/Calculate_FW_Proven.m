function FW_Proven_Factor = Calculate_FW_Proven(Filtered_FW_Vector, Signing_ClubTier);

    FW_Proven_Tier1 = {'Lautaro Martinez', 'Son Heung-Min', 'Alexander Isak', 'Raphinha', 'Julián Álvarez'};
    FW_Proven_Tier2 = {'Rodrygo', 'Leroy Sané', 'Christopher Nkunku', 'Dušan Vlahović', 'Diogo Jota', 'Ollie Watkins', 'Serhou Guirasy', 'Luis Díaz', 'Marcus Thuram', 'Patrik Schick', 'Kingsley Coman'};
    FW_Proven_Tier3 = {'Rafael Leão', 'Kai Havertz', 'Jarrod Bowen', 'Mateo Retegui', 'Victor Boniface', 'Nicolas Jackson', 'Serge Gnabry', 'Ademola Lookman', 'Jean-Phillipe Mateta'};
    %Listing players by their past achievements (performances stats
    %trophies etc.)

    FW_Proven_Factor = ones(height(Filtered_FW_Vector), 1);
    %Set default multiplier to 1

    if Signing_ClubTier <= 2
        for i = 1:height(Filtered_FW_Vector)
        %Tier 1 and 2 clubs recommended proven players
        
            PlayerName = Filtered_FW_Vector.Player{i};
            %For loop checks player name every iteration

            if ismember(PlayerName, FW_Proven_Tier1)
                FW_Proven_Factor(i) = 1.5;
            elseif ismember(PlayerName, FW_Proven_Tier2)
                FW_Proven_Factor(i) = 1.35;
            elseif ismember(PlayerName, FW_Proven_Tier3)
                FW_Proven_Factor(i) = 1.15;
                %Apply 1.5x to tier1 hype, 1.35x to tier2 hype and 1.15x to tier3                
            end
        end
    end
end