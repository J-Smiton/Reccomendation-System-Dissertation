function Club = GetClubName()

    if evalin('base', 'exist(''ClubName'', ''var'')')
        Club = evalin('base', 'ClubName');
        evalin('base', 'clear ClubName');
    else
        Club = input('Enter club name: ', 's');
    end
end