function GK_Fringe_Players = Suggest_GK_Fringe_Players(GK_Vector, Target_GK_ClubTier, Signing_ClubTier);

    Target_GK_ClubTier = GK_Vector.ClubTier;
    %Specify variable for club of players being suggested
    Fringe_GK_Minutes = GK_Vector.Min;
    %Specify variable for minutes of fringe players

    GK_Fringe_Players = table();
    %Create a table of fringe players

    Non_Fringe_Players = {'', '', '', '', '', '', '', '',  '', ''};
    %Create a list of notable exceptions (for injuries and Jnauary
    %transfers)

    if Signing_ClubTier >= 3
    %Only for tier 3, 4 and 5 clubs
        GK_Fringe_Targets = Target_GK_ClubTier <= 2;
        %Suggest tier 1+2 players
        Fringe_MFs = Fringe_GK_Minutes <= 500;
        %Who have 500 or less minutes
        Eligible_Fringe_GKs = Fringe_MFs & GK_Fringe_Targets;
        %Eligible for a fringe signing if they're tier1/2 and have <500 min
        GK_Fringe_Players = GK_Vector(Eligible_Fringe_GKs, :);
        %Create variable holding fringe players
        Excluded_GKs = ismember(GK_Fringe_Players.Player, Non_Fringe_Players);
        %Implement exclusions 
        GK_Fringe_Players(Excluded_GKs, :) = [];
        %Minus excluded goalkeepers

        Opportunity_Label = repmat("Fringe Transfer", height(GK_Fringe_Players), 1);
        %Add 'fringe players' to opportunity label for players over 23
        Opportunity_Label(GK_Fringe_Players.Age <= 23) = "Loan Opportunity";
        %Add 'loan opportunity' to players 23 and under
        GK_Fringe_Players.Opportunity = Opportunity_Label;
        %Apply label with description of potential signing

        GK_Fringe_Players = sortrows(GK_Fringe_Players, 'Rk');
        %Sort players by their 'Rk' (Rank)-Alphabetical
    else
        GK_Fringe_Players = table();
        %Empty table for tier 1, 2 and 3 clubs
    end 
end