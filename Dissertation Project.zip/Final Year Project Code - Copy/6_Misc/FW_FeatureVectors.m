FW_FeatureVectors = readtable('Norm_DissData_FW_Val_Final.csv')

FW_FeatureVectors = [FW_FeatureVectors.Gls_norm, FW_FeatureVectors.G_A_norm, FW_FeatureVectors.xG_norm, FW_FeatureVectors.npxG_xAG_norm, FW_FeatureVectors.PrgC_norm, FW_FeatureVectors.SoT_norm];

FW_FeatureMatrix = Norm_DissData_FW_Val_Final{:, Features};

Similarity = CosineSimilarityMatrix(FW_FeatureMatrix, ClubVector);

