playerTable  = readtable('DissData.xlsx');
%load player data

[Squad, squadNames] = findgroups(playerTable.Squad);
%group data by squads

teamAvgAge = splitapply(@mean, playerTable.Age, Squad);
%avg the ages of each team
teamAgeTable = table(squadNames, teamAvgAge);
%convert the values into a table

disp(teamAgeTable)
%show the table