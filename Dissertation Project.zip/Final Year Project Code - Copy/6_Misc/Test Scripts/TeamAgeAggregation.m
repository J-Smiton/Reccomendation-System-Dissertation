playerTable  = readtable('DissData.csv');

[Squad, squadNames] = findgroups(playerTable.Squad);

teamAvgAge = splitapply(@mean, playerTable.Age, Squad);
teamAgeTable = table(squadNames, teamAvgAge);
 
disp(teamAgeTable)