%Input Checking

if ~istable(plpayerTable)
     disp('Input "playerTable" must be a MATLAB table');
end
%throws error if playerTable isnt a table

if ~iscell(meanStats)
    disp('meanStats must be a cell array')
end

if ~iscell(sumStats)
    disp('sumStats must be a cell array')
end
%throws errors if sumStats or arent cell arrays

if ~all(ismember(meanStats, PlayerTable.Properties.VariableNames))
    disp('some meanStats are missing from the table')
end

if ~all(ismember(sumStats, PlayerTable.Properties.VariableNames))
    disp('some sumStats are missing from the table')
end
%throws errors if stats are missing from the respective tables