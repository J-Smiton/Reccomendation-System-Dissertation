Teamstat1 = 'Avg_SoT_'
%Define the first team stat for normalisation
MinVal = min(finalTeamStats.(Teamstat1));
%Define the minimum value of the stat
MaxVal = max(finalTeamStats.(Teamstat1));
%Define the maximum value of the stat
finalTeamStats.([Teamstat1 '_norm']) = (finalTeamStats.(Teamstat1) - MinVal) / (MaxVal - MinVal);
%Calculate the normalised value based on the formula

%Repeat the process for remaining stats

Teamstat2 = 'Avg_SoT_90_Player'
MinVal = min(finalTeamStats.(Teamstat2));
MaxVal = max(finalTeamStats.(Teamstat2));
finalTeamStats.([Teamstat2 '_norm']) = (finalTeamStats.(Teamstat2) - MinVal) / (MaxVal - MinVal);

Teamstat3 = 'Avg_G_Sh'
MinVal = min(finalTeamStats.(Teamstat3));
MaxVal = max(finalTeamStats.(Teamstat3));
finalTeamStats.([Teamstat3 '_norm']) = (finalTeamStats.(Teamstat3) - MinVal) / (MaxVal - MinVal);

Teamstat4 = 'Avg_Cmp_'
MinVal = min(finalTeamStats.(Teamstat4));
MaxVal = max(finalTeamStats.(Teamstat4));
finalTeamStats.([Teamstat4 '_norm']) = (finalTeamStats.(Teamstat4) - MinVal) / (MaxVal - MinVal);

Teamstat5 = 'Avg_Tkl_'
MinVal = min(finalTeamStats.(Teamstat5));
MaxVal = max(finalTeamStats.(Teamstat5));
finalTeamStats.([Teamstat5 '_norm']) = (finalTeamStats.(Teamstat5) - MinVal) / (MaxVal - MinVal);

Teamstat6 = 'Avg_GA90'
MinVal = min(finalTeamStats.(Teamstat6));
MaxVal = max(finalTeamStats.(Teamstat6));
finalTeamStats.([Teamstat6 '_norm']) = (finalTeamStats.(Teamstat6) - MinVal) / (MaxVal - MinVal);

Teamstat7 = 'Avg_Save_'
MinVal = min(finalTeamStats.(Teamstat7));
MaxVal = max(finalTeamStats.(Teamstat7));
finalTeamStats.([Teamstat7 '_norm']) = (finalTeamStats.(Teamstat7) - MinVal) / (MaxVal - MinVal);

Teamstat8 = 'Avg_CS_'
MinVal = min(finalTeamStats.(Teamstat8));
MaxVal = max(finalTeamStats.(Teamstat8));
finalTeamStats.([Teamstat8 '_norm']) = (finalTeamStats.(Teamstat8) - MinVal) / (MaxVal - MinVal);

Teamstat9 = 'Avg_x_90PSxG_GA_90'
MinVal = min(finalTeamStats.(Teamstat9));
MaxVal = max(finalTeamStats.(Teamstat9));
finalTeamStats.([Teamstat9 '_norm']) = (finalTeamStats.(Teamstat9) - MinVal) / (MaxVal - MinVal);

Teamstat10 = 'Avg_GKCmp_'
MinVal = min(finalTeamStats.(Teamstat10));
MaxVal = max(finalTeamStats.(Teamstat10));
finalTeamStats.([Teamstat10 '_norm']) = (finalTeamStats.(Teamstat10) - MinVal) / (MaxVal - MinVal);

Teamstat11 = 'Avg_Launch_'
MinVal = min(finalTeamStats.(Teamstat11));
MaxVal = max(finalTeamStats.(Teamstat11));
finalTeamStats.([Teamstat11 '_norm']) = (finalTeamStats.(Teamstat11) - MinVal) / (MaxVal - MinVal);

Teamstat12 = 'Avg_Stp_'
MinVal = min(finalTeamStats.(Teamstat12));
MaxVal = max(finalTeamStats.(Teamstat12));
finalTeamStats.([Teamstat12 '_norm']) = (finalTeamStats.(Teamstat12) - MinVal) / (MaxVal - MinVal);

Teamstat13 = 'Avg_OPA_90'
MinVal = min(finalTeamStats.(Teamstat13));
MaxVal = max(finalTeamStats.(Teamstat13));
finalTeamStats.([Teamstat13 '_norm']) = (finalTeamStats.(Teamstat13) - MinVal) / (MaxVal - MinVal);

Teamstat14 = 'Ttl_Gls'
MinVal = min(finalTeamStats.(Teamstat14));
MaxVal = max(finalTeamStats.(Teamstat14));
finalTeamStats.([Teamstat14 '_norm']) = (finalTeamStats.(Teamstat14) - MinVal) / (MaxVal - MinVal);

Teamstat15 = 'Ttl_Ast'
MinVal = min(finalTeamStats.(Teamstat15));
MaxVal = max(finalTeamStats.(Teamstat15));
finalTeamStats.([Teamstat15 '_norm']) = (finalTeamStats.(Teamstat15) - MinVal) / (MaxVal - MinVal);

Teamstat16 = 'Ttl_G_A'
MinVal = min(finalTeamStats.(Teamstat16));
MaxVal = max(finalTeamStats.(Teamstat16));
finalTeamStats.([Teamstat16 '_norm']) = (finalTeamStats.(Teamstat16) - MinVal) / (MaxVal - MinVal);

Teamstat17 = 'Ttl_PK'
MinVal = min(finalTeamStats.(Teamstat17));
MaxVal = max(finalTeamStats.(Teamstat17));
finalTeamStats.([Teamstat17 '_norm']) = (finalTeamStats.(Teamstat17) - MinVal) / (MaxVal - MinVal);

Teamstat18 = 'Ttl_CrdY'
MinVal = min(finalTeamStats.(Teamstat18));
MaxVal = max(finalTeamStats.(Teamstat18));
finalTeamStats.([Teamstat18 '_norm']) = (finalTeamStats.(Teamstat18) - MinVal) / (MaxVal - MinVal);

Teamstat19 = 'Ttl_CrdR'
MinVal = min(finalTeamStats.(Teamstat19));
MaxVal = max(finalTeamStats.(Teamstat19));
finalTeamStats.([Teamstat19 '_norm']) = (finalTeamStats.(Teamstat19) - MinVal) / (MaxVal - MinVal);

Teamstat20 = 'Ttl_xG'
MinVal = min(finalTeamStats.(Teamstat20));
MaxVal = max(finalTeamStats.(Teamstat20));
finalTeamStats.([Teamstat20 '_norm']) = (finalTeamStats.(Teamstat20) - MinVal) / (MaxVal - MinVal);

Teamstat21 = 'Ttl_xAG'
MinVal = min(finalTeamStats.(Teamstat21));
MaxVal = max(finalTeamStats.(Teamstat21));
finalTeamStats.([Teamstat21 '_norm']) = (finalTeamStats.(Teamstat21) - MinVal) / (MaxVal - MinVal);

Teamstat22 = 'Ttl_npxG_xAG'
MinVal = min(finalTeamStats.(Teamstat22));
MaxVal = max(finalTeamStats.(Teamstat22));
finalTeamStats.([Teamstat22 '_norm']) = (finalTeamStats.(Teamstat22) - MinVal) / (MaxVal - MinVal);

Teamstat23 = 'Ttl_PrgC'
MinVal = min(finalTeamStats.(Teamstat23));
MaxVal = max(finalTeamStats.(Teamstat23));
finalTeamStats.([Teamstat23 '_norm']) = (finalTeamStats.(Teamstat23) - MinVal) / (MaxVal - MinVal);

Teamstat24 = 'Ttl_TotDist'
MinVal = min(finalTeamStats.(Teamstat24));
MaxVal = max(finalTeamStats.(Teamstat24));
finalTeamStats.([Teamstat24 '_norm']) = (finalTeamStats.(Teamstat24) - MinVal) / (MaxVal - MinVal);

Teamstat25 = 'Ttl_PrgDist'
MinVal = min(finalTeamStats.(Teamstat25));
MaxVal = max(finalTeamStats.(Teamstat25));
finalTeamStats.([Teamstat25 '_norm']) = (finalTeamStats.(Teamstat25) - MinVal) / (MaxVal - MinVal);

Teamstat26 = 'Ttl_TB'
MinVal = min(finalTeamStats.(Teamstat26));
MaxVal = max(finalTeamStats.(Teamstat26));
finalTeamStats.([Teamstat26 '_norm']) = (finalTeamStats.(Teamstat26) - MinVal) / (MaxVal - MinVal);

Teamstat27 = 'Ttl_Crs'
MinVal = min(finalTeamStats.(Teamstat27));
MaxVal = max(finalTeamStats.(Teamstat27));
finalTeamStats.([Teamstat27 '_norm']) = (finalTeamStats.(Teamstat27) - MinVal) / (MaxVal - MinVal);

Teamstat28 = 'Ttl_CK'
MinVal = min(finalTeamStats.(Teamstat28));
MaxVal = max(finalTeamStats.(Teamstat28));
finalTeamStats.([Teamstat28 '_norm']) = (finalTeamStats.(Teamstat28) - MinVal) / (MaxVal - MinVal);

Teamstat29 = 'Ttl_Tkl'
MinVal = min(finalTeamStats.(Teamstat29));
MaxVal = max(finalTeamStats.(Teamstat29));
finalTeamStats.([Teamstat29 '_norm']) = (finalTeamStats.(Teamstat29) - MinVal) / (MaxVal - MinVal);

Teamstat30 = 'Ttl_Def3rd'
MinVal = min(finalTeamStats.(Teamstat30));
MaxVal = max(finalTeamStats.(Teamstat30));
finalTeamStats.([Teamstat30 '_norm']) = (finalTeamStats.(Teamstat30) - MinVal) / (MaxVal - MinVal);

Teamstat31 = 'Ttl_Blocks'
MinVal = min(finalTeamStats.(Teamstat31));
MaxVal = max(finalTeamStats.(Teamstat31));
finalTeamStats.([Teamstat31 '_norm']) = (finalTeamStats.(Teamstat31) - MinVal) / (MaxVal - MinVal);

Teamstat32 = 'Ttl_Int'
MinVal = min(finalTeamStats.(Teamstat32));
MaxVal = max(finalTeamStats.(Teamstat32));
finalTeamStats.([Teamstat32 '_norm']) = (finalTeamStats.(Teamstat32) - MinVal) / (MaxVal - MinVal);

Teamstat33 = 'Ttl_Tkl_Int'
MinVal = min(finalTeamStats.(Teamstat33));
MaxVal = max(finalTeamStats.(Teamstat33));
finalTeamStats.([Teamstat33 '_norm']) = (finalTeamStats.(Teamstat33) - MinVal) / (MaxVal - MinVal);

Teamstat34 = 'Ttl_Clr'
MinVal = min(finalTeamStats.(Teamstat34));
MaxVal = max(finalTeamStats.(Teamstat34));
finalTeamStats.([Teamstat34 '_norm']) = (finalTeamStats.(Teamstat34) - MinVal) / (MaxVal - MinVal);

Teamstat35 = 'Ttl_Err'
MinVal = min(finalTeamStats.(Teamstat35));
MaxVal = max(finalTeamStats.(Teamstat35));
finalTeamStats.([Teamstat35 '_norm']) = (finalTeamStats.(Teamstat35) - MinVal) / (MaxVal - MinVal);

Teamstat36 = 'Ttl_Rec'
MinVal = min(finalTeamStats.(Teamstat36));
MaxVal = max(finalTeamStats.(Teamstat36));
finalTeamStats.([Teamstat36 '_norm']) = (finalTeamStats.(Teamstat36) - MinVal) / (MaxVal - MinVal);

Teamstat37 = 'Ttl_Fls'
MinVal = min(finalTeamStats.(Teamstat37));
MaxVal = max(finalTeamStats.(Teamstat37));
finalTeamStats.([Teamstat37 '_norm']) = (finalTeamStats.(Teamstat37) - MinVal) / (MaxVal - MinVal);

Teamstat38 = 'Ttl_PKwon'
MinVal = min(finalTeamStats.(Teamstat38));
MaxVal = max(finalTeamStats.(Teamstat38));
finalTeamStats.([Teamstat38 '_norm']) = (finalTeamStats.(Teamstat38) - MinVal) / (MaxVal - MinVal);

Teamstat39 = 'Ttl_Recov'
MinVal = min(finalTeamStats.(Teamstat39));
MaxVal = max(finalTeamStats.(Teamstat39));
finalTeamStats.([Teamstat39 '_norm']) = (finalTeamStats.(Teamstat39) - MinVal) / (MaxVal - MinVal);

Teamstat40 = 'Ttl_PKA'
MinVal = min(finalTeamStats.(Teamstat40));
MaxVal = max(finalTeamStats.(Teamstat40));
finalTeamStats.([Teamstat40 '_norm']) = (finalTeamStats.(Teamstat40) - MinVal) / (MaxVal - MinVal);

Teamstat41 = 'Ttl_PKsv'
MinVal = min(finalTeamStats.(Teamstat41));
MaxVal = max(finalTeamStats.(Teamstat41));
finalTeamStats.([Teamstat41 '_norm']) = (finalTeamStats.(Teamstat41) - MinVal) / (MaxVal - MinVal);

Norm_finalTeamStats = finalTeamStats
%Create table with normalised team values

writetable(Norm_finalTeamStats, 'Norm_finalTeamStats.csv');
%Write table to be accessed in excel

