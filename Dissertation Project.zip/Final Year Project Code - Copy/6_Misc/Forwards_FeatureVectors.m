FW_Vector = readtable('Norm_DissData_FW_Val_Final.csv');
%Load normalised forward data

FW_Features = ["Gls_norm", "G_A_norm", "xG_norm", "npxG_xAG_norm", "PrgC_norm", "SoT__norm"];
%Add chosen stats to feature list

FW_FeatureMatrix = FW_Vector{:, FW_Features};
%Implement this into the feature matrix

Club_Vector = readtable('Norm_finalTeamStats.csv');
%Load normalised club data

Club_Features = ["Ttl_Gls_norm", "Ttl_G_A_norm", "Ttl_xG_norm", "Ttl_npxG_xAG_norm", "Ttl_PrgC_norm", "Avg_SoT__norm"];
%Add the same stats to feature list

Club_Matrix = Club_Vector{:, Club_Features};
%Implement this into the feature matrix

Club_Profile = Club_Matrix(1, :);
%Set this up as the club profile

Signability = FW_Vector.ValTiers <= (Club_Vector.ClubTier + 1)

Filtered_FW_Vector = FW_Vector(Signability, :);
Filtered_FW_FeatureMatrix = FW_FeatureMatrix(Signability, :);

disp(size(Filtered_FW_FeatureMatrix))
disp(size(Club_Profile))

SimilarityScores = CosineSimilarity(Filtered_FW_FeatureMatrix, Club_Profile);
%Calculate similarity scores using cosine similarity

disp(SimilarityScores)

Complementary_Scores = 1 - SimilarityScores
%Create complementary scores using 1 - similarity scores

Filtered_FW_Vector.SimilarityScore = SimilarityScores
%Create a similarity score under the forward vector

Filtered_FW_Vector = sortrows(Filtered_FW_Vector, 'SimilarityScores', 'descend');
%Sort players by their similarity score

SuggestionNumber = 20;
%Number of suggested players shown for the club bsaed on similarity score

SuggestedSignings = Filtered_FW_Vector(1:SuggestionNumber, :);
%Save suggested signings under a variable

writetable(SuggestedSignings, 'Top_FW_Suggestions_Club1.csv')
%Display the suggested signings in a table