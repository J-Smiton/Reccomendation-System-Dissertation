playerTable  = readtable('DissData.xlsx');

[Squad, squadNames] = findgroups(playerTable.Squad);

teamAvgAgw = splitapply(@mean, playerTable.Age, Squad);
teamAgeTable = table(squadNames, teamAvgAge);

disp(teamAgeTable)