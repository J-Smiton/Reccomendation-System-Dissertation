MFstat1 = 'Gls'
%Define the first midfielder stat for normalisation
MinVal = min(DissData_MF_Val_Final.(MFstat1));
%Define the minimum value of the stat
MaxVal = max(DissData_MF_Val_Final.(MFstat1));
%Define the maximum value of the stat
DissData_MF_Val_Final.([MFstat1 '_norm']) = (DissData_MF_Val_Final.(MFstat1) - MinVal) / (MaxVal - MinVal);
%Calculate the normalised value based on the formula

%Repeat the process for remaining stats

MFstat2 = 'Ast'
MinVal = min(DissData_MF_Val_Final.(MFstat2));
MaxVal = max(DissData_MF_Val_Final.(MFstat2));
DissData_MF_Val_Final.([MFstat2 '_norm']) = (DissData_MF_Val_Final.(MFstat2) - MinVal) / (MaxVal - MinVal);

MFstat3 = 'G_A'
MinVal = min(DissData_MF_Val_Final.(MFstat3));
MaxVal = max(DissData_MF_Val_Final.(MFstat3));
DissData_MF_Val_Final.([MFstat3 '_norm']) = (DissData_MF_Val_Final.(MFstat3) - MinVal) / (MaxVal - MinVal);

MFstat4 = 'PK'
MinVal = min(DissData_MF_Val_Final.(MFstat4));
MaxVal = max(DissData_MF_Val_Final.(MFstat4));
DissData_MF_Val_Final.([MFstat4 '_norm']) = (DissData_MF_Val_Final.(MFstat4) - MinVal) / (MaxVal - MinVal);

MFstat5 = 'CrdY'
MinVal = min(DissData_MF_Val_Final.(MFstat5));
MaxVal = max(DissData_MF_Val_Final.(MFstat5));
DissData_MF_Val_Final.([MFstat5 '_norm']) = (DissData_MF_Val_Final.(MFstat5) - MinVal) / (MaxVal - MinVal);

MFstat6 = 'CrdR'
MinVal = min(DissData_MF_Val_Final.(MFstat6));
MaxVal = max(DissData_MF_Val_Final.(MFstat6));
DissData_MF_Val_Final.([MFstat6 '_norm']) = (DissData_MF_Val_Final.(MFstat6) - MinVal) / (MaxVal - MinVal);

MFstat7 = 'xG'
MinVal = min(DissData_MF_Val_Final.(MFstat7));
MaxVal = max(DissData_MF_Val_Final.(MFstat7));
DissData_MF_Val_Final.([MFstat7 '_norm']) = (DissData_MF_Val_Final.(MFstat7) - MinVal) / (MaxVal - MinVal);

MFstat8 = 'xAG'
MinVal = min(DissData_MF_Val_Final.(MFstat8));
MaxVal = max(DissData_MF_Val_Final.(MFstat8));
DissData_MF_Val_Final.([MFstat8 '_norm']) = (DissData_MF_Val_Final.(MFstat8) - MinVal) / (MaxVal - MinVal);

MFstat9 = 'npxG_xAG'
MinVal = min(DissData_MF_Val_Final.(MFstat9));
MaxVal = max(DissData_MF_Val_Final.(MFstat9));
DissData_MF_Val_Final.([MFstat9 '_norm']) = (DissData_MF_Val_Final.(MFstat9) - MinVal) / (MaxVal - MinVal);

MFstat10 = 'PrgC'
MinVal = min(DissData_MF_Val_Final.(MFstat10));
MaxVal = max(DissData_MF_Val_Final.(MFstat10));
DissData_MF_Val_Final.([MFstat10 '_norm']) = (DissData_MF_Val_Final.(MFstat10) - MinVal) / (MaxVal - MinVal);

MFstat11 = 'PrgP'
MinVal = min(DissData_MF_Val_Final.(MFstat11));
MaxVal = max(DissData_MF_Val_Final.(MFstat11));
DissData_MF_Val_Final.([MFstat11 '_norm']) = (DissData_MF_Val_Final.(MFstat11) - MinVal) / (MaxVal - MinVal);

MFstat12 = 'SoT_'
MinVal = min(DissData_MF_Val_Final.(MFstat12));
MaxVal = max(DissData_MF_Val_Final.(MFstat12));
DissData_MF_Val_Final.([MFstat12 '_norm']) = (DissData_MF_Val_Final.(MFstat12) - MinVal) / (MaxVal - MinVal);

MFstat13 = 'SoT_90'
MinVal = min(DissData_MF_Val_Final.(MFstat13));
MaxVal = max(DissData_MF_Val_Final.(MFstat13));
DissData_MF_Val_Final.([MFstat13 '_norm']) = (DissData_MF_Val_Final.(MFstat13) - MinVal) / (MaxVal - MinVal);

MFstat14 = 'G_Sh'
MinVal = min(DissData_MF_Val_Final.(MFstat14));
MaxVal = max(DissData_MF_Val_Final.(MFstat14));
DissData_MF_Val_Final.([MFstat14 '_norm']) = (DissData_MF_Val_Final.(MFstat14) - MinVal) / (MaxVal - MinVal);

MFstat15 = 'G_xG'
MinVal = min(DissData_MF_Val_Final.(MFstat15));
MaxVal = max(DissData_MF_Val_Final.(MFstat15));
DissData_MF_Val_Final.([MFstat15 '_norm']) = (DissData_MF_Val_Final.(MFstat15) - MinVal) / (MaxVal - MinVal);

MFstat16 = 'Cmp_'
MinVal = min(DissData_MF_Val_Final.(MFstat16));
MaxVal = max(DissData_MF_Val_Final.(MFstat16));
DissData_MF_Val_Final.([MFstat16 '_norm']) = (DissData_MF_Val_Final.(MFstat16) - MinVal) / (MaxVal - MinVal);

MFstat17 = 'TotDist'
MinVal = min(DissData_MF_Val_Final.(MFstat17));
MaxVal = max(DissData_MF_Val_Final.(MFstat17));
DissData_MF_Val_Final.([MFstat17 '_norm']) = (DissData_MF_Val_Final.(MFstat17) - MinVal) / (MaxVal - MinVal);

MFstat18 = 'PrgDist'
MinVal = min(DissData_MF_Val_Final.(MFstat18));
MaxVal = max(DissData_MF_Val_Final.(MFstat18));
DissData_MF_Val_Final.([MFstat18 '_norm']) = (DissData_MF_Val_Final.(MFstat18) - MinVal) / (MaxVal - MinVal);

MFstat19 = 'TB'
MinVal = min(DissData_MF_Val_Final.(MFstat19));
MaxVal = max(DissData_MF_Val_Final.(MFstat19));
DissData_MF_Val_Final.([MFstat19 '_norm']) = (DissData_MF_Val_Final.(MFstat19) - MinVal) / (MaxVal - MinVal);

MFstat20 = 'Crs'
MinVal = min(DissData_MF_Val_Final.(MFstat20));
MaxVal = max(DissData_MF_Val_Final.(MFstat20));
DissData_MF_Val_Final.([MFstat20 '_norm']) = (DissData_MF_Val_Final.(MFstat20) - MinVal) / (MaxVal - MinVal);

MFstat21 = 'CK'
MinVal = min(DissData_MF_Val_Final.(MFstat21));
MaxVal = max(DissData_MF_Val_Final.(MFstat21));
DissData_MF_Val_Final.([MFstat21 '_norm']) = (DissData_MF_Val_Final.(MFstat21) - MinVal) / (MaxVal - MinVal);

MFstat22 = 'Tkl'
MinVal = min(DissData_MF_Val_Final.(MFstat22));
MaxVal = max(DissData_MF_Val_Final.(MFstat22));
DissData_MF_Val_Final.([MFstat22 '_norm']) = (DissData_MF_Val_Final.(MFstat22) - MinVal) / (MaxVal - MinVal);

MFstat23 = 'Def3rd'
MinVal = min(DissData_MF_Val_Final.(MFstat23));
MaxVal = max(DissData_MF_Val_Final.(MFstat23));
DissData_MF_Val_Final.([MFstat23 '_norm']) = (DissData_MF_Val_Final.(MFstat23) - MinVal) / (MaxVal - MinVal);

MFstat24 = 'Tkl_'
MinVal = min(DissData_MF_Val_Final.(MFstat24));
MaxVal = max(DissData_MF_Val_Final.(MFstat24));
DissData_MF_Val_Final.([MFstat24 '_norm']) = (DissData_MF_Val_Final.(MFstat24) - MinVal) / (MaxVal - MinVal);

MFstat25 = 'Blocks'
MinVal = min(DissData_MF_Val_Final.(MFstat25));
MaxVal = max(DissData_MF_Val_Final.(MFstat25));
DissData_MF_Val_Final.([MFstat25 '_norm']) = (DissData_MF_Val_Final.(MFstat25) - MinVal) / (MaxVal - MinVal);

MFstat26 = 'Int'
MinVal = min(DissData_MF_Val_Final.(MFstat26));
MaxVal = max(DissData_MF_Val_Final.(MFstat26));
DissData_MF_Val_Final.([MFstat26 '_norm']) = (DissData_MF_Val_Final.(MFstat26) - MinVal) / (MaxVal - MinVal);

MFstat27 = 'Tkl_Int'
MinVal = min(DissData_MF_Val_Final.(MFstat27));
MaxVal = max(DissData_MF_Val_Final.(MFstat27));
DissData_MF_Val_Final.([MFstat27 '_norm']) = (DissData_MF_Val_Final.(MFstat27) - MinVal) / (MaxVal - MinVal);

MFstat28 = 'Clr'
MinVal = min(DissData_MF_Val_Final.(MFstat28));
MaxVal = max(DissData_MF_Val_Final.(MFstat28));
DissData_MF_Val_Final.([MFstat28 '_norm']) = (DissData_MF_Val_Final.(MFstat28) - MinVal) / (MaxVal - MinVal);

MFstat29 = 'Err'
MinVal = min(DissData_MF_Val_Final.(MFstat29));
MaxVal = max(DissData_MF_Val_Final.(MFstat29));
DissData_MF_Val_Final.([MFstat29 '_norm']) = (DissData_MF_Val_Final.(MFstat29) - MinVal) / (MaxVal - MinVal);

MFstat30 = 'Rec'
MinVal = min(DissData_MF_Val_Final.(MFstat30));
MaxVal = max(DissData_MF_Val_Final.(MFstat30));
DissData_MF_Val_Final.([MFstat30 '_norm']) = (DissData_MF_Val_Final.(MFstat30) - MinVal) / (MaxVal - MinVal);

MFstat31 = 'Fls'
MinVal = min(DissData_MF_Val_Final.(MFstat31));
MaxVal = max(DissData_MF_Val_Final.(MFstat31));
DissData_MF_Val_Final.([MFstat31 '_norm']) = (DissData_MF_Val_Final.(MFstat31) - MinVal) / (MaxVal - MinVal);

MFstat32 = 'PKwon'
MinVal = min(DissData_MF_Val_Final.(MFstat32));
MaxVal = max(DissData_MF_Val_Final.(MFstat32));
DissData_MF_Val_Final.([MFstat32 '_norm']) = (DissData_MF_Val_Final.(MFstat32) - MinVal) / (MaxVal - MinVal);

MFstat33 = 'Recov'
MinVal = min(DissData_MF_Val_Final.(MFstat33));
MaxVal = max(DissData_MF_Val_Final.(MFstat33));
DissData_MF_Val_Final.([MFstat33 '_norm']) = (DissData_MF_Val_Final.(MFstat33) - MinVal) / (MaxVal - MinVal);

Norm_DissData_MF_Val_Final = DissData_MF_Val_Final;
%Create table with normalised midfielder values

writetable(Norm_DissData_MF_Val_Final, 'Norm_DissData_MF_Val_Final.csv');
%Write table to be accessed in excel