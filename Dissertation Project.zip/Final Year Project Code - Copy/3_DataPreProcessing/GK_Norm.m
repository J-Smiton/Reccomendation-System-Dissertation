GKstat1 = 'CrdY'
%Define the first goalkeeper stat for normalisation
MinVal = min(DissData_GK_Val_Final.(GKstat1));
%Define the minimum value of the stat
MaxVal = max(DissData_GK_Val_Final.(GKstat1));
%Define the maximum value of the stat
DissData_GK_Val_Final.([GKstat1 '_norm']) = (DissData_GK_Val_Final.(GKstat1) - MinVal) / (MaxVal - MinVal);
%Calculate the normalised value based on the formula

%Repeat the process for remaining stats

GKstat2 = 'CrdR'
MinVal = min(DissData_GK_Val_Final.(GKstat2));
MaxVal = max(DissData_GK_Val_Final.(GKstat2));
DissData_GK_Val_Final.([GKstat2 '_norm']) = (DissData_GK_Val_Final.(GKstat2) - MinVal) / (MaxVal - MinVal);

GKstat3 = 'xAG'
MinVal = min(DissData_GK_Val_Final.(GKstat3));
MaxVal = max(DissData_GK_Val_Final.(GKstat3));
DissData_GK_Val_Final.([GKstat3 '_norm']) = (DissData_GK_Val_Final.(GKstat3) - MinVal) / (MaxVal - MinVal);

GKstat4 = 'Cmp_'
MinVal = min(DissData_GK_Val_Final.(GKstat4));
MaxVal = max(DissData_GK_Val_Final.(GKstat4));
DissData_GK_Val_Final.([GKstat4 '_norm']) = (DissData_GK_Val_Final.(GKstat4) - MinVal) / (MaxVal - MinVal);

GKstat5 = 'Err'
MinVal = min(DissData_GK_Val_Final.(GKstat5));
MaxVal = max(DissData_GK_Val_Final.(GKstat5));
DissData_GK_Val_Final.([GKstat5 '_norm']) = (DissData_GK_Val_Final.(GKstat5) - MinVal) / (MaxVal - MinVal);

GKstat6 = 'Fls'
MinVal = min(DissData_GK_Val_Final.(GKstat6));
MaxVal = max(DissData_GK_Val_Final.(GKstat6));
DissData_GK_Val_Final.([GKstat6 '_norm']) = (DissData_GK_Val_Final.(GKstat6) - MinVal) / (MaxVal - MinVal);

GKstat7 = 'GA90'
MinVal = min(DissData_GK_Val_Final.(GKstat7));
MaxVal = max(DissData_GK_Val_Final.(GKstat7));
DissData_GK_Val_Final.([GKstat7 '_norm']) = (DissData_GK_Val_Final.(GKstat7) - MinVal) / (MaxVal - MinVal);

GKstat8 = 'Save_'
MinVal = min(DissData_GK_Val_Final.(GKstat8));
MaxVal = max(DissData_GK_Val_Final.(GKstat8));
DissData_GK_Val_Final.([GKstat8 '_norm']) = (DissData_GK_Val_Final.(GKstat8) - MinVal) / (MaxVal - MinVal);

GKstat9 = 'CS_'
MinVal = min(DissData_GK_Val_Final.(GKstat9));
MaxVal = max(DissData_GK_Val_Final.(GKstat9));
DissData_GK_Val_Final.([GKstat9 '_norm']) = (DissData_GK_Val_Final.(GKstat9) - MinVal) / (MaxVal - MinVal);

GKstat10 = 'PKA'
MinVal = min(DissData_GK_Val_Final.(GKstat10));
MaxVal = max(DissData_GK_Val_Final.(GKstat10));
DissData_GK_Val_Final.([GKstat10 '_norm']) = (DissData_GK_Val_Final.(GKstat10) - MinVal) / (MaxVal - MinVal);

GKstat11 = 'PKsv'
MinVal = min(DissData_GK_Val_Final.(GKstat11));
MaxVal = max(DissData_GK_Val_Final.(GKstat11));
DissData_GK_Val_Final.([GKstat11 '_norm']) = (DissData_GK_Val_Final.(GKstat11) - MinVal) / (MaxVal - MinVal);

GKstat12 = 'x_90PSxG_GA_90'
MinVal = min(DissData_GK_Val_Final.(GKstat12));
MaxVal = max(DissData_GK_Val_Final.(GKstat12));
DissData_GK_Val_Final.([GKstat12 '_norm']) = (DissData_GK_Val_Final.(GKstat12) - MinVal) / (MaxVal - MinVal);

GKstat13 = 'GKCmp_'
MinVal = min(DissData_GK_Val_Final.(GKstat13));
MaxVal = max(DissData_GK_Val_Final.(GKstat13));
DissData_GK_Val_Final.([GKstat13 '_norm']) = (DissData_GK_Val_Final.(GKstat13) - MinVal) / (MaxVal - MinVal);

GKstat14 = 'Launch_'
MinVal = min(DissData_GK_Val_Final.(GKstat14));
MaxVal = max(DissData_GK_Val_Final.(GKstat14));
DissData_GK_Val_Final.([GKstat14 '_norm']) = (DissData_GK_Val_Final.(GKstat14) - MinVal) / (MaxVal - MinVal);

GKstat15 = 'Stp_'
MinVal = min(DissData_GK_Val_Final.(GKstat15));
MaxVal = max(DissData_GK_Val_Final.(GKstat15));
DissData_GK_Val_Final.([GKstat15 '_norm']) = (DissData_GK_Val_Final.(GKstat15) - MinVal) / (MaxVal - MinVal);

GKstat16 = 'OPA_90'
MinVal = min(DissData_GK_Val_Final.(GKstat16));
MaxVal = max(DissData_GK_Val_Final.(GKstat16));
DissData_GK_Val_Final.([GKstat16 '_norm']) = (DissData_GK_Val_Final.(GKstat16) - MinVal) / (MaxVal - MinVal);

Norm_DissData_GK_Val_Final = DissData_GK_Val_Final
%Create table with normalised goalkeeper values

writetable(Norm_DissData_GK_Val_Final, 'Norm_DissData_GK_Val_Final.csv');
%Write table to be accessed in excel