FWstat1 = 'Gls'
%Define the first forward stat for normalisation
MinVal = min(DissData_FW_Val_Final.(FWstat1));
%Define the minimum value of the stat
MaxVal = max(DissData_FW_Val_Final.(FWstat1));
%Define the maximum value ofthe stat
DissData_FW_Val_Final.([FWstat1 '_norm']) = (DissData_FW_Val_Final.(FWstat1) - MinVal) / (MaxVal - MinVal);
%Calculate the normalised value based on the formula

%Repeat the process for remaining stats

FWstat2 = 'Ast'
MinVal = min(DissData_FW_Val_Final.(FWstat2));
MaxVal = max(DissData_FW_Val_Final.(FWstat2));
DissData_FW_Val_Final.([FWstat2 '_norm']) = (DissData_FW_Val_Final.(FWstat2) - MinVal) / (MaxVal - MinVal);

FWstat3 = 'G_A'
MinVal = min(DissData_FW_Val_Final.(FWstat3));
MaxVal = max(DissData_FW_Val_Final.(FWstat3));
DissData_FW_Val_Final.([FWstat3 '_norm']) = (DissData_FW_Val_Final.(FWstat3) - MinVal) / (MaxVal - MinVal);

FWstat4 = 'PK'
MinVal = min(DissData_FW_Val_Final.(FWstat4));
MaxVal = max(DissData_FW_Val_Final.(FWstat4));
DissData_FW_Val_Final.([FWstat4 '_norm']) = (DissData_FW_Val_Final.(FWstat4) - MinVal) / (MaxVal - MinVal);

FWstat5 = 'CrdY'
MinVal = min(DissData_FW_Val_Final.(FWstat5));
MaxVal = max(DissData_FW_Val_Final.(FWstat5));
DissData_FW_Val_Final.([FWstat5 '_norm']) = (DissData_FW_Val_Final.(FWstat5) - MinVal) / (MaxVal - MinVal);

FWstat6 = 'CrdR'
MinVal = min(DissData_FW_Val_Final.(FWstat6));
MaxVal = max(DissData_FW_Val_Final.(FWstat6));
DissData_FW_Val_Final.([FWstat6 '_norm']) = (DissData_FW_Val_Final.(FWstat6) - MinVal) / (MaxVal - MinVal);

FWstat7 = 'xG'
MinVal = min(DissData_FW_Val_Final.(FWstat7));
MaxVal = max(DissData_FW_Val_Final.(FWstat7));
DissData_FW_Val_Final.([FWstat7 '_norm']) = (DissData_FW_Val_Final.(FWstat7) - MinVal) / (MaxVal - MinVal);

FWstat8 = 'xAG'
MinVal = min(DissData_FW_Val_Final.(FWstat8));
MaxVal = max(DissData_FW_Val_Final.(FWstat8));
DissData_FW_Val_Final.([FWstat8 '_norm']) = (DissData_FW_Val_Final.(FWstat8) - MinVal) / (MaxVal - MinVal);

FWstat9 = 'npxG_xAG'
MinVal = min(DissData_FW_Val_Final.(FWstat9));
MaxVal = max(DissData_FW_Val_Final.(FWstat9));
DissData_FW_Val_Final.([FWstat9 '_norm']) = (DissData_FW_Val_Final.(FWstat9) - MinVal) / (MaxVal - MinVal);

FWstat10 = 'PrgC'
MinVal = min(DissData_FW_Val_Final.(FWstat10));
MaxVal = max(DissData_FW_Val_Final.(FWstat10));
DissData_FW_Val_Final.([FWstat10 '_norm']) = (DissData_FW_Val_Final.(FWstat10) - MinVal) / (MaxVal - MinVal);

FWstat11 = 'SoT_'
MinVal = min(DissData_FW_Val_Final.(FWstat11));
MaxVal = max(DissData_FW_Val_Final.(FWstat11));
DissData_FW_Val_Final.([FWstat11 '_norm']) = (DissData_FW_Val_Final.(FWstat11) - MinVal) / (MaxVal - MinVal);

FWstat12 = 'SoT_90'
MinVal = min(DissData_FW_Val_Final.(FWstat12));
MaxVal = max(DissData_FW_Val_Final.(FWstat12));
DissData_FW_Val_Final.([FWstat12 '_norm']) = (DissData_FW_Val_Final.(FWstat12) - MinVal) / (MaxVal - MinVal);

FWstat13 = 'G_Sh'
MinVal = min(DissData_FW_Val_Final.(FWstat13));
MaxVal = max(DissData_FW_Val_Final.(FWstat13));
DissData_FW_Val_Final.([FWstat13 '_norm']) = (DissData_FW_Val_Final.(FWstat13) - MinVal) / (MaxVal - MinVal);

FWstat14 = 'G_xG'
MinVal = min(DissData_FW_Val_Final.(FWstat14));
MaxVal = max(DissData_FW_Val_Final.(FWstat14));
DissData_FW_Val_Final.([FWstat14 '_norm']) = (DissData_FW_Val_Final.(FWstat14) - MinVal) / (MaxVal - MinVal);

FWstat15 = 'PKwon'
MinVal = min(DissData_FW_Val_Final.(FWstat15));
MaxVal = max(DissData_FW_Val_Final.(FWstat15));
DissData_FW_Val_Final.([FWstat15 '_norm']) = (DissData_FW_Val_Final.(FWstat15) - MinVal) / (MaxVal - MinVal);

Norm_DissData_FW_Val_Final = DissData_FW_Val_Final;
%Create table with normalised forward values

writetable(Norm_DissData_FW_Val_Final, 'Norm_DissData_FW_Val_Final.csv')
%Write table to be accessed in excel