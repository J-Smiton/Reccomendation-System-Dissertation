DFstat1 = 'Ast'
%Define the first defender stat for normalisation
MinVal = min(DissData_DF_Val_Final.(DFstat1));
%Define the minimum value of the stat
MaxVal = max(DissData_DF_Val_Final.(DFstat1));
%Define the maximum value of the stat
DissData_DF_Val_Final.([DFstat1 '_norm']) = (DissData_DF_Val_Final.(DFstat1) - MinVal) / (MaxVal - MinVal);
%Calculate the normalised value based on the formula

%Repeat the process for remaining stats

DFstat2 = 'CrdY'
MinVal = min(DissData_DF_Val_Final.(DFstat2));
MaxVal = max(DissData_DF_Val_Final.(DFstat2));
DissData_DF_Val_Final.([DFstat2 '_norm']) = (DissData_DF_Val_Final.(DFstat2) - MinVal) / (MaxVal - MinVal);

DFstat3 = 'CrdR'
MinVal = min(DissData_DF_Val_Final.(DFstat3));
MaxVal = max(DissData_DF_Val_Final.(DFstat3));
DissData_DF_Val_Final.([DFstat3 '_norm']) = (DissData_DF_Val_Final.(DFstat3) - MinVal) / (MaxVal - MinVal);

DFstat4 = 'xAG'
MinVal = min(DissData_DF_Val_Final.(DFstat4));
MaxVal = max(DissData_DF_Val_Final.(DFstat4));
DissData_DF_Val_Final.([DFstat4 '_norm']) = (DissData_DF_Val_Final.(DFstat4) - MinVal) / (MaxVal - MinVal);

DFstat5 = 'PrgC'
MinVal = min(DissData_DF_Val_Final.(DFstat5));
MaxVal = max(DissData_DF_Val_Final.(DFstat5));
DissData_DF_Val_Final.([DFstat5 '_norm']) = (DissData_DF_Val_Final.(DFstat5) - MinVal) / (MaxVal - MinVal);

DFstat6 = 'Cmp_'
MinVal = min(DissData_DF_Val_Final.(DFstat6));
MaxVal = max(DissData_DF_Val_Final.(DFstat6));
DissData_DF_Val_Final.([DFstat6 '_norm']) = (DissData_DF_Val_Final.(DFstat6) - MinVal) / (MaxVal - MinVal);

DFstat7 = 'Tkl'
MinVal = min(DissData_DF_Val_Final.(DFstat7));
MaxVal = max(DissData_DF_Val_Final.(DFstat7));
DissData_DF_Val_Final.([DFstat7 '_norm']) = (DissData_DF_Val_Final.(DFstat7) - MinVal) / (MaxVal - MinVal);

DFstat8 = 'Def3rd'
MinVal = min(DissData_DF_Val_Final.(DFstat8));
MaxVal = max(DissData_DF_Val_Final.(DFstat8));
DissData_DF_Val_Final.([DFstat8 '_norm']) = (DissData_DF_Val_Final.(DFstat8) - MinVal) / (MaxVal - MinVal);

DFstat9 = 'Tkl_'
MinVal = min(DissData_DF_Val_Final.(DFstat9));
MaxVal = max(DissData_DF_Val_Final.(DFstat9));
DissData_DF_Val_Final.([DFstat9 '_norm']) = (DissData_DF_Val_Final.(DFstat9) - MinVal) / (MaxVal - MinVal);

DFstat10 = 'Blocks'
MinVal = min(DissData_DF_Val_Final.(DFstat10));
MaxVal = max(DissData_DF_Val_Final.(DFstat10));
DissData_DF_Val_Final.([DFstat10 '_norm']) = (DissData_DF_Val_Final.(DFstat10) - MinVal) / (MaxVal - MinVal);

DFstat11 = 'Int'
MinVal = min(DissData_DF_Val_Final.(DFstat11));
MaxVal = max(DissData_DF_Val_Final.(DFstat11));
DissData_DF_Val_Final.([DFstat11 '_norm']) = (DissData_DF_Val_Final.(DFstat11) - MinVal) / (MaxVal - MinVal);

DFstat12 = 'Tkl_Int'
MinVal = min(DissData_DF_Val_Final.(DFstat12));
MaxVal = max(DissData_DF_Val_Final.(DFstat12));
DissData_DF_Val_Final.([DFstat12 '_norm']) = (DissData_DF_Val_Final.(DFstat12) - MinVal) / (MaxVal - MinVal);

DFstat13 = 'Clr'
MinVal = min(DissData_DF_Val_Final.(DFstat13));
MaxVal = max(DissData_DF_Val_Final.(DFstat13));
DissData_DF_Val_Final.([DFstat13 '_norm']) = (DissData_DF_Val_Final.(DFstat13) - MinVal) / (MaxVal - MinVal);

DFstat14 = 'Err'
MinVal = min(DissData_DF_Val_Final.(DFstat14));
MaxVal = max(DissData_DF_Val_Final.(DFstat14));
DissData_DF_Val_Final.([DFstat14 '_norm']) = (DissData_DF_Val_Final.(DFstat14) - MinVal) / (MaxVal - MinVal);

DFstat15 = 'Rec'
MinVal = min(DissData_DF_Val_Final.(DFstat15));
MaxVal = max(DissData_DF_Val_Final.(DFstat15));
DissData_DF_Val_Final.([DFstat15 '_norm']) = (DissData_DF_Val_Final.(DFstat15) - MinVal) / (MaxVal - MinVal);

DFstat16 = 'Fls'
MinVal = min(DissData_DF_Val_Final.(DFstat16));
MaxVal = max(DissData_DF_Val_Final.(DFstat16));
DissData_DF_Val_Final.([DFstat16 '_norm']) = (DissData_DF_Val_Final.(DFstat16) - MinVal) / (MaxVal - MinVal);

DFstat17 = 'Recov'
MinVal = min(DissData_DF_Val_Final.(DFstat17));
MaxVal = max(DissData_DF_Val_Final.(DFstat17));
DissData_DF_Val_Final.([DFstat17 '_norm']) = (DissData_DF_Val_Final.(DFstat17) - MinVal) / (MaxVal - MinVal);

Norm_DissData_DF_Val_Final = DissData_DF_Val_Final
%Create table with normalised defender values

writetable(Norm_DissData_DF_Val_Final, 'Norm_DissData_DF_Val_Final.csv');
%Write table to be accessed in excel










