DissData_GK_Val_Final = readtable('DissData_GK_Val_Final.csv');

DissData_DF_Val_Final = readtable('DissData_DF_Val_Final.csv');

DissData_MF_Val_Final = readtable('DissData_MF_Val_Final.xlsx');

DissData_FW_Val_Final = readtable('DissData_FW_Val_Final.csv');

finalTeamStats = readtable('finalTeamStats.csv');
%Read all tables

if any(ismissing(DissData_GK_Val_Final), 'all')
    disp('some stats are missing from the GK table')
else 
    disp('no stats are missing from the GK table')
end

if any(ismissing(DissData_DF_Val_Final), 'all')
    disp('some stats are missing from the DF table')
else 
    disp('no stats are missing from the DF table')
end

if any(ismissing(DissData_MF_Val_Final), 'all')
    disp('some stats are missing from the MF table')
else 
    disp('no stats are missing from the MF table')
end

if any(ismissing(DissData_FW_Val_Final), 'all')
    disp('some stats are missing from the FW table')
else 
    disp('no stats are missing from the FW table')
end

if any(ismissing(finalTeamStats), 'all')
    disp('some stats are missing from the teams table')
else 
    disp('no stats are missing from the teams table')
end

%Check all tables and display if there are or aren't any stats missing

