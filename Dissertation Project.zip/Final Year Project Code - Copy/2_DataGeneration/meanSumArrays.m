meanStats = {'SoT_', 'SoT_90', 'G_Sh', 'Cmp_', 'Tkl_', 'GA90', 'Save_', 'CS_', 'x_90PSxG_GA_90', 'GKCmp_', 'Launch_', 'Stp_', 'OPA_90'};

sumStats = {'Gls', 'Ast', 'G_A', 'PK', 'CrdY', 'CrdR', 'xG', 'xAG', 'npxG_xAG', 'PrgC', 'PrgP', 'G_xG', 'TotDist', 'PrgDist', 'TB', 'Crs', 'CK', 'Tkl', 'Def3rd', 'Blocks', 'Int', 'Tkl_Int', 'Clr', 'Err', 'Rec', 'Fls', 'PKwon', 'Recov', 'PKA', 'PKsv'};

