DissData_GK = readtable("DissData_GK.csv");
%Make sure the goalkeeper dataset is updated

ClubTiers = finalTeamStats(:, {'Squad', 'ClubTier'});
%Only take squad and club tier from the team dataset

setdiff(DissData_GK.Squad, ClubTiers.Squad)
%Check for difference in team names

DissData_GK_Val = outerjoin(DissData_GK, ClubTiers, "Keys","Squad", "Type", "Left");
%Join the datasets by team

head(DissData_GK_Val)
%Show table

DissData_GK_Val = sortrows(DissData_GK_Val, 'Rk', 'ascend')
%Sort by RK/ID

writetable(DissData_GK_Val, 'DissData_GK_Val.csv');
%Upload to be manipulated in excel