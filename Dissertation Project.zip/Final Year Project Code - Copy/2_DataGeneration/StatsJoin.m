meanStats = {'SoT_', 'SoT_90', 'G_Sh', 'Cmp_', 'Tkl_', 'GA90', 'Save_', 'CS_', 'x_90PSxG_GA_90', 'GKCmp_', 'Launch_', 'Stp_', 'OPA_90'};
%statistics that will be averaged in the teams table

sumStats = {'Gls', 'Ast', 'G_A', 'PK', 'CrdY', 'CrdR', 'xG', 'xAG', 'npxG_xAG', 'PrgC', 'PrgP', 'G_xG', 'TotDist', 'PrgDist', 'TB', 'Crs', 'CK', 'Tkl', 'Def3rd', 'Blocks', 'Int', 'Tkl_Int', 'Clr', 'Err', 'Rec', 'Fls', 'PKwon', 'Recov', 'PKA', 'PKsv'};
%statistics that will be added in the teams table

teamStatsMean = groupsummary(playerTable, 'Squad', 'mean', meanStats);

teamStatsSum = groupsummary(playerTable, 'Squad', 'sum', sumStats);

TeamStats = join(teamStatsMean, teamStatsSum, 'Keys', 'Squad');
%join both the averages and the sums of the stats
