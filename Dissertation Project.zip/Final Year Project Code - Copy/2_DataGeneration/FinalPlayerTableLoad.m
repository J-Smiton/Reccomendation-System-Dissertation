finalTeamStats = readtable("finalTeamStats.csv")
%load stats from csv