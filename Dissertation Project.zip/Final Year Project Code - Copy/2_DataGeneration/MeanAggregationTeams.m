teamStats = table();
%put the team stats into a table

for i = 1:length(meanStats)
    stat = meanStats{i};
    teamStats.(stat) = varfun(@mean, playerTable, 'InputVariables', stat, 'GroupingVariables', 'Squad');
end

%loop for adding up each stat which needs to be averaged