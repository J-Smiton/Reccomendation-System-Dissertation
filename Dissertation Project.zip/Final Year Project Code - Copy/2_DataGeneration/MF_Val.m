DissData_MF = readtable("DissData_MF.csv");
%Make sure the midfielder dataset is updated

ClubTiers = finalTeamStats(:, {'Squad', 'ClubTier'});
%Only take squad and club tier from the team dataset

setdiff(DissData_MF.Squad, ClubTiers.Squad)
%Check for difference in team names

DissData_MF_Val = outerjoin(DissData_MF, ClubTiers, "Keys","Squad", "Type", "Left");
%Join the datasets by team

head(DissData_MF_Val)
%Show table

DissData_MF_Val = sortrows(DissData_MF_Val, 'Rk', 'ascend')
%Sort by RK/ID

writetable(DissData_MF_Val, 'DissData_MF_Val.csv');
%Upload to be manipulated in excel
