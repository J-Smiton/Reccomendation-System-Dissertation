DissData_FW = readtable("DissData_FW.csv");
%Make sure the forward dataset is updated

ClubTiers = finalTeamStats(:, {'Squad', 'ClubTier'});
%Only take squad and club tier from the team dataset

setdiff(DissData_FW.Squad, ClubTiers.Squad)
%Check for difference in team names

DissData_FW_Val = outerjoin(DissData_FW, ClubTiers, "Keys","Squad", "Type", "Left");
%Join the datasets by team

head(DissData_FW_Val)
%Show table

DissData_FW_Val = sortrows(DissData_FW_Val, 'Rk', 'ascend')
%Sort by RK/ID

writetable(DissData_FW_Val, 'DissData_FW_Val.csv');
%Upload to be manipulated in excel