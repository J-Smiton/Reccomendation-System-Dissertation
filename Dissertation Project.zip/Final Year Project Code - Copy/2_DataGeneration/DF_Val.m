DissData_DF = readtable("DissData_DF.csv");
%Make sure the defender dataset is updated

ClubTiers = finalTeamStats(:, {'Squad', 'ClubTier'});
%Only take squad and club tier from the team dataset

setdiff(DissData_DF.Squad, ClubTiers.Squad)
%Check for difference in team names

DissData_DF_Val = outerjoin(DissData_DF, ClubTiers, "Keys","Squad", "Type", "Left");
%Join the datasets by team

head(DissData_DF_Val)
%Show table

DissData_DF_Val = sortrows(DissData_DF_Val, 'Rk', 'ascend')
%Sort by RK/ID

writetable(DissData_DF_Val, 'DissData_DF_Val.csv');
%Upload to be manipulated in excel