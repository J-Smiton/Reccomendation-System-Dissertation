teamStatsSum = table();
%put the team stats into a table
for i = 1:length(sumStats)
    stat = sumStats{i};
    teamStatsSum.(stat) = varfun(@sum, playerTable, 'InputVariables', stat, 'GroupingVariables', 'Squad');
end

%loop for adding up each stat which needs to be summed