Minutes = DissData_FW.Min;
%create a avriable which holds minutes played by forwards to be used

histogram(Minutes, 'BinWidth', 250);
%create histogram with specific binwidth for visualisation purposes
xlabel('Minutes played');
ylabel('Number of players');
title('Visualisation of minutes played by forwards');

xticks(0:250:max(Minutes))
%display minutes played in increments of 250 (roughly 3 matches)